<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="keywords" content="">
    <!-- facebook -->
    <meta property="og:url" content="https://spqr.eecs.umich.edu/" />
	<meta property="og:site_name" content="SPQR - Security and Privacy Research Group" />
	<meta property="og:type" content="website" />
	<meta property="og:title" content="SPQR - Security and Privacy Research Group" />
	<meta property="og:image" content="http://localhost/spqr/images/SPQR-logo.jpg" />
	<meta property="og:description" content="" />

    <link rel="shortcut icon" href="images/spqr-favicon.png">

    <title>SPQR &mdash; Michigan EECS</title>

    <!-- Bootstrap core CSS -->
    <link href="dist/css/bootstrap.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy this line! -->
    <!--[if lt IE 9]><script src="../../docs-assets/js/ie8-responsive-file-warning.js"></script><![endif]-->

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->

    <!-- Custom styles for this template -->
    <link href="styles/bootstrap-spqr.css" rel="stylesheet">

  </head>  <body>
	    <div class="navbar-wrapper">
      <div class="container">

        <div class="navbar navbar-inverse navbar-static-top" role="navigation">
          <div class="container">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              <a class="navbar-brand" href="index.php">
              <div class="nav-header-logo">
                <script src="spqr.js"></script>
		<span onMouseOver="SPQRlink(this)">
              	<img src="images/SPQR-logo.jpg" class="nav-header-logo-img">
		</span>
              </div>
              <div class="nav-header-headline">Security and Privacy Research Group</div>
              <div class="nav-header-text">Computer Science & Engineering | University of Michigan</div> 
              </a>
            </div>
            <div class="navbar-collapse collapse">
              <ul class="nav navbar-nav">
               <li ><a href="index.php">HOME</a></li>
                <li ><a href="people.php">PEOPLE</a></li>
                <li ><a href="publications.php">PUBLICATIONS</a></li>
                <li ><a href="projects.php">PROJECTS</a></li>
                <li  class="active" ><a href="news.php">NEWS & EVENTS</a></li>
                <li ><a href="seminars.php">SEMINARS</a></li>
                <li ><a href="jobs.php">JOBS</a></li>
                <li ><a href="https://twitter.com/spqrfridge">SMART FRIDGE</a></li>
              </ul>
            </div>
          </div>
        </div>

      </div>
    </div>	<div class="container marketing">
      <div class="col-md-12 content-first-col news">
      <h2>News & Events</h2>
      <br />
      <p>We've moved our news to the <a href="http://cse.umich.edu/">main departmental web site</a>.</p>
      <br />
      <div class="row">
  		<div class="col-md-1 newsNext"><h2>2013</h2></div>
    	<div class="col-md-1"><h2>Jan</h2></div>
  		<div class="col-md-10">&nbsp;</div>
  	  </div>
  	  <div class="row">
  		<div class="col-md-1">&nbsp;</div>
  		<div class="col-md-1">&nbsp;</div>
  		<div class="col-md-10 newsItem newsNext"><a target="_blank" href="http://www.eecs.umich.edu/courses/eecs598-008/">First graduate course in the nation dedicated to medical device security</a> (January 2013)</div>
  	  </div>
  	  <div class="row">
  		<div class="col-md-1">&nbsp;</div>
  		<div class="col-md-1">&nbsp;</div>
  		<div class="col-md-10 newsItem"><a target="_blank" href="http://www.futurearchs.org">$28M Center for Future Architectures Research (C-FAR)</a> (January 2013)</div>
  	  </div>      
  	  <div class="row">
  		<div class="col-md-1">&nbsp;</div>
  		<div class="col-md-1">&nbsp;</div>
  		<div class="col-md-10 newsItem newsNext"><a target="_blank" href="http://terraswarm.org/">$27.5M TerraSwarm Research Center</a> (January 2013)</div>
  	  </div> 
      <div class="row">
  		<div class="col-md-1 newsNext"><h2>2012</h2></div>
    	<div class="col-md-1"><h2>Nov</h2></div>
  		<div class="col-md-10"></div>
  	  </div>  	        
  	  <div class="row">
  		<div class="col-md-1">&nbsp;</div>
  		<div class="col-md-1">&nbsp;</div>
  		<div class="col-md-10 newsItem newsNext">Prof. Kevin Fu <a target="_blank" href="http://energycommerce.house.gov/hearing/examining-options-combat-health-care-waste-fraud-and-abuse">testifies in Congress</a> on the <a target="_blank" href="http://energycommerce.house.gov/sites/republicans.energycommerce.house.gov/files/Hearings/Health/20121128/HHRG-112-IF14-WState-FuK-20121128.pdf">expectations of smart cards to reduce Medicare fraud</a>, and causes a <a target="_blank" href="http://www.youtube.com/watch?feature=player_embedded&v=1dcJBa0aLKk#at=5267">bipartisan laugh when explaining identity authentication</a> (November 2012).</div>
  	  </div>   
  	  <div class="row"> 
  	  	<div class="col-md-1"></div>
    	<div class="col-md-1"><h2>Oct</h2></div>
  		<div class="col-md-10"></div>  
  	  </div>		  
  	  <div class="row">
  		<div class="col-md-1">&nbsp;</div>
  		<div class="col-md-1">&nbsp;</div>
  		<div class="col-md-10 newsItem"><a target="_blank" href="http://www.technologyreview.com/news/429616/computer-viruses-are-rampant-on-medical-devices-in-hospitals/">MIT Technology Review on medical device malware</a> (October 2012)</div>
  	  </div>  
  	  <div class="row"> 
  	  	<div class="col-md-1"></div>
    	<div class="col-md-1"><h2>Aug</h2></div>
  		<div class="col-md-10"></div>  
  	  </div>  	  
  	  <div class="row">
  		<div class="col-md-1">&nbsp;</div>
  		<div class="col-md-1">&nbsp;</div>
  		<div class="col-md-10 newsItem newsNext"><a target="_blank" href="http://conferences.sigcomm.org/sigcomm/2012/medcomm.php">MedCOMM2012</a> will <a href="events/2012-medcomm/">streamlive</a> from Finland (August 13, 2012) </div>
  	  </div>   	  
  	  <div class="row">
  		<div class="col-md-1">&nbsp;</div>
  		<div class="col-md-1">&nbsp;</div>
  		<div class="col-md-10 newsItem"><a target="_blank" href="http://spectrum.ieee.org/semiconductors/memory/could-an-sram-hourglass-save-rfid-chips-just-in-time">IEEESpectrum</a> and <a target="_blank" href="http://it.slashdot.org/story/12/08/07/006229/time-machines-computer-memory-and-brute-force-attacks-against-smartcards">Slashdot</a> cover the TARDIS paper at USENIX Security.</div>
  	  </div>  
  	  <div class="row"> 
  	  	<div class="col-md-1"></div>
    	<div class="col-md-1"><h2>Jun</h2></div>
  		<div class="col-md-10"></div>  
  	  </div>   	  
  	  <div class="row">
  		<div class="col-md-1">&nbsp;</div>
  		<div class="col-md-1">&nbsp;</div>
  		<div class="col-md-10 newsItem newsNext">SPQR research on <a target="_blank" href="http://www.economist.com/node/21556098">medical devices featured in the Economist</a> (June 2, 2012)</div>
  	  </div>    	    	  
  	  <div class="row">
  		<div class="col-md-1">&nbsp;</div>
  		<div class="col-md-1">&nbsp;</div>
  		<div class="col-md-10 newsItem">Prof. Fu joins <a target="_blank" href="news/FinalRetreatSheet.pdf">distinguished speakers</a> (including the current NSADirector and former CIA Director) at the <a target="_blank" href="http://www.npsfoundation.org/index.cfm/trustees.htm">Naval Postgraduate School Foundation</a> retreat</div>
  	  </div>  
  	  <div class="row"> 
  	  	<div class="col-md-1"></div>
    	<div class="col-md-1"><h2>Apr</h2></div>
  		<div class="col-md-10"></div>  
  	  </div>   	  
  	  <div class="row">
  		<div class="col-md-1">&nbsp;</div>
  		<div class="col-md-1">&nbsp;</div>
  		<div class="col-md-10 newsItem newsNext">Forbes covers <a target="_blank" href="http://www.forbes.com/sites/marcwebertobias/2012/04/20/whats-to-stop-hackers-from-infecting-medical-devices/">SPQR research on medical device security</a></div>
  	  </div>  
  	  <div class="row">
  		<div class="col-md-1">&nbsp;</div>
  		<div class="col-md-1">&nbsp;</div>
  		<div class="col-md-10 newsItem">BBC discusses <a  target="_blank" href="http://www.bbc.com/news/technology-17623948">cyber security of medical implants</a></div>
  	  </div>  
  	  <div class="row">
  		<div class="col-md-1">&nbsp;</div>
  		<div class="col-md-1">&nbsp;</div>
  		<div class="col-md-10 newsItem newsNext">The NIST Information Security and Privacy Advisory Board issues a <a target="_blank" href="http://csrc.nist.gov/groups/SMA/ispab/documents/correspondence/ispab-ltr-to-omb_med_device.pdf">letter on medical device cybersecurity</a> to the Acting Director  of <a target="_blank" href="http://www.whitehouse.gov/omb">OMB</a>, the <a target="_blank" href="http://www.hhs.gov/secretary/about/biography/index.html">Secretary of HHS</a>, the <a target="_blank" href="http://www.cio.gov/module.cfm/node/about/asec/3">CIO of OMB</a>, the <a target="_blank" href="http://www.whitehouse.gov/cybersecurity">Cyber security Coordinator of the National Security Council</a>, the Deputy Under secretary for <a target="_blank" href="http://www.dhs.gov/files/cybersecurity.shtm">Cybersecurity at DHS</a>, and the <a target="_blank" href="http://www.nist.gov/director/">Director of NIST</a>.</div>
  	  </div>    
  	  <div class="row">
  		<div class="col-md-1 newsNext"><h2>Older</h2></div>
  		<div class="col-md-1">&nbsp;</div>
  		<div class="col-md-10"></div>
  	  </div>  
  	  <div class="row">
  		<div class="col-md-2"></div>
  		<div class="col-md-10 newsItem"><a target="_blank" href="http://articles.latimes.com/2011/sep/01/nation/la-na-fda-devices-20110901">LosAngeles Times discusses regulation of medical device software</a> (September1, 2011)</div>
  	  </div>  
  	  <div class="row">
  		<div class="col-md-2"></div>
  		<div class="col-md-10 newsItem newsNext">The IEEE Oakland paper on <a target="_blank" href="http://secure-medicine.org/">security of implantable medical devices</a> makes an unusual appearance in a <a target="_blank" href="http://blog.secure-medicine.org/2011/09/hugh-darrow-and-medical-device-security.html"> popular video game called Deus Ex: Human Revolution</a></div>
  	  </div>  
  	  <div class="row">
  		<div class="col-md-2"></div>
  		<div class="col-md-10 newsItem"><a target="_blank" href="http://groups.csail.mit.edu/netmit/IMDShield/">IMDShield</a> receives <a target="_blank" href="http://conferences.sigcomm.org/sigcomm/2011/">best paper award from ACM SIGCOMM</a></div>
  	  </div>    
  	  <div class="row">
  		<div class="col-md-2"></div>
  		<div class="col-md-10 newsItem newsNext">UMass Amherst hosts the <a target="_blank" href="http://rfid-cusp.org/rfidsec/">7th Workshop on RFID Security and Privacy</a></div>
  	  </div>  
  	  <div class="row">
  		<div class="col-md-2"></div>
  		<div class="col-md-10 newsItem"><a target="_blank" href="http://www.consumerreports.org/cro/magazine-archive/2011/june/money/credit-card-fraud/overview/index.htm">Consumer Reports features SPQR Lab research on RFID credit cards</a></div>
  	  </div>  
  	  <div class="row">
  		<div class="col-md-2"></div>
  		<div class="col-md-10 newsItem newsNext">Gift of <a target="_blank" href="http://www.umass.edu/loop/talkingpoints/articles/123845.php">differential power analysis workstation</a> from <a href="http://www.cryptography.com/">Cryptography Research</a></div>
  	  </div>  
  	  <div class="row">
  		<div class="col-md-2"></div>
  		<div class="col-md-10 newsItem"><a target="_blank" href="http://spectrum.ieee.org/semiconductors/devices/flash-memory-for-dull-devices">IEEESpectrum</a> covers <a href="half-wits/">Half-Witspaper</a> for low-power embedded flash memory</div>
  	  </div>      	    	    	    	   	       
  	  <div class="row">
  		<div class="col-md-2"></div>
  		<div class="col-md-10 newsItem newsNext">Kevin Fu elevated to <a target="_blank" href="http://senior.acm.org/">ACM Senior Member</a></div>
  	  </div>  
  	  <div class="row">
  		<div class="col-md-2"></div>
  		<div class="col-md-10 newsItem"><a target="_blank" href="http://www.signalprocessingsociety.org/awards-fellows/fellows-programs/">Wayne Burleson and Christof Paar elevated to IEEE Fellow</a></div>
  	  </div>  
  	  <div class="row">
  		<div class="col-md-2"></div>
  		<div class="col-md-10 newsItem newsNext"><a target="_blank" href="http://sharps.org/">$15M Security of Healthcare IT grant</a> awarded by DHHS</div>
  	  </div>  
  	  <div class="row">
  		<div class="col-md-2"></div>
  		<div class="col-md-10 newsItem"><a target="_blank" href="http://www.cs.umass.edu/~ssclark/">Shane Clark</a> receives 3-year NSF Graduate Research Fellowship</div>
  	  </div>  
  	  <div class="row">
  		<div class="col-md-2"></div>
  		<div class="col-md-10 newsItem newsNext"><a target="_blank" href="http://www.umass.edu/newsoffice/newsreleases/articles/102541.php">$1.17M Transportation Payments Security &amp; Privacy grant</a> awarded by NSF</div>
  	  </div>  
  	  <div class="row">
  		<div class="col-md-2"></div>
  		<div class="col-md-10 newsItem">$450K MRI grant for an RFID Testbed awarded by NSF</div>
  	  </div>  
  	  <div class="row">
  		<div class="col-md-2"></div>
  		<div class="col-md-10 newsItem newsNext"><a target="_blank" href="http://www.umass.edu/loop/talkingpoints/articles/96152.php">CAREER grant awarded by NSF</a></div>
  	  </div>    	    	    	    
  	  <div class="row">
  		<div class="col-md-2"></div>
  		<div class="col-md-10 newsItem"><a target="_blank" href="http://www.cs.umass.edu/~ransford/">Ben Ransford</a> receives 3-year NSF Graduate Research Fellowship</div>
  	  </div>    	    	    	    
  	  <div class="row">
  		<div class="col-md-2"></div>
  		<div class="col-md-10 newsItem newsNext">$450K Cyber Trust grant on Improving S&amp;P in Pervasive Healthcare awarded by NSF</div>
  	  </div>    	    	    	    
  	  <div class="row">
  		<div class="col-md-2"></div>
  		<div class="col-md-10 newsItem">Kevin Fu named <a href="http://www.technologyreview.com/TR35/index.aspx?year=2009&channel=All">MIT Technology Review TR35 Innovator of the Year</a></div>
  	  </div>    	    	    	    
  	  <div class="row">
  		<div class="col-md-2"></div>
  		<div class="col-md-10 newsItem newsNext">Kevin Fu receives <a href="http://www.umass.edu/loop/talkingpoints/articles/84219.php">Sloan Research Fellowship</a></div>
  	  </div>    	    	    	    
  	  <div class="row">
  		<div class="col-md-2"></div>
  		<div class="col-md-10 newsItem">The ITPS workshop</a> brought together academic, industrial, and government participants to brainstorm how to <a target="_blank" href="http://www.ecs.umass.edu/umass_itps_workshop/">improve security and privacy of integrated payment systems for transportation</a>.</div>
  	  </div>    	    	    	    
  	  <div class="row">
  		<div class="col-md-2"></div>
  		<div class="col-md-10 newsItem newsNext"><a target="_blank" href="http://spectrum.ieee.org/mar09/8251/2">IEEE Spectrum interviews Prof. Wayne Burleson and Dan Holcomb</a> on using the contents of uninitialized SRAM to generate randomness and an identifying fingerprint on future RFID tags.</div>
  	  </div>    	    	    	    
  	  <div class="row">
  		<div class="col-md-2"></div>
  		<div class="col-md-10 newsItem">Prof. Wayne Burleson and Dr. Ari Juels are collaborating with Prof. Dennis Goeckel and Prof. Robert Jackson of the UMass Wireless Center on a new project entitled <a target="_blank" href="http://www.umass.edu/loop/talkingpoints/articles/80265.php">&quot;Ultra Wideband Radio for Low-Power Security.&quot;</a>. The project was recently <a target="_blank" href="http://www.masshightech.com/stories/2008/10/27/daily25-UMass-Amherst-reserachers-get-NSF-grant-to-improve-RFID.html">awarded a $200,000 grant from the NSF Cyber Trust</a> program.</div>
  	  </div>    	    	    	    
  	  <div class="row">
  		<div class="col-md-2"></div>
  		<div class="col-md-10 newsItem newsNext">Prof. Kevin Fu explained the challenges for <a target="_blank" href="http://www.cs.umass.edu/~kevinfu/talks/Fu-Fed-Reserve-Chicago.pdf">security and privacy of contactless credit cards, NFC phones, and chip-and-pin</a> to attendees at the <a target="_blank" href="http://www.chicagofed.org/">2008 Payments Conference</a> organized by the Federal Reserve Bank of Chicago.</div>
  	  </div>    	    	    	    
  	  <div class="row">
  		<div class="col-md-2"></div>
  		<div class="col-md-10 newsItem"> <a target="_blank" href="http://www.ieee-security.org/TC/SP2008/oakland08-award-papers.html">Outstanding Paper Award</a> at the 29th Annual IEEE Symposium on Security &amp; Privacy for the paper entitled, <a target="_blank" href="http://www.secure-medicine.org/icd-study/icd-study.pdf">&quot;Pacemakers and implantable cardiac defibrillators: Software-radio attacks and zero-power defenses.&quot;</a></div>
  	  </div>    	    	    	    
  	  <div class="row">
  		<div class="col-md-2"></div>
  		<div class="col-md-10 newsItem newsNext">An implantable cardioverter defibrillator can leak private information and allow unauthorized parties to modify settings that control shock therapies. Read the <a target="_blank" href="http://www.secure-medicine.org/">full report</a> and coverage by the <a target="_blank" href="http://www.nytimes.com/2008/03/12/business/12heart-web.html">New York Times</a>, <a target="_blank" href="http://online.wsj.com/article/SB120528705417629357.html?mod=hpp_us_whats_news">Wall Street Journal</a>, and a <a target="_blank" href="http://www.umass.edu/newsoffice/newsreleases/articles/72864.php">press release</a></div>
  	  </div>    	    	    	    
  	  <div class="row">
  		<div class="col-md-2"></div>
  		<div class="col-md-10 newsItem">Researchers from academia, industry, and government participated in the <a  href="http://rfid-cusp.org/workshop/2008/post_workshop.html">RFID Security Workshop</a> at Johns Hopkins University in Baltimore.  The original <a  href="http://rfid-cusp.org/workshop.html">workshop program appears here</a>.</div>
  	  </div>    	    	    	    
  	  <div class="row">
  		<div class="col-md-2"></div>
  		<div class="col-md-10 newsItem newsNext">The RFID Journal <a target="_blank" href="http://www.rfidjournal.com/article/articleview/3723/1/1/">reports</a> Daniel Holcomb's work on <a target="_blank" href="publications.php?q=FERNS">using the initial SRAM state for fingerprint extraction and random number generation</a> on RFIDs. A journal version appears in IEEE Trans. on Computers</a>.</div>
  	  </div>    	    	    	    
  	  <div class="row">
  		<div class="col-md-2"></div>
  		<div class="col-md-10 newsItem">Prof. Kevin Fu discusses <a target="_blank" href="http://www.cfp2007.org/live/program.html">security and privacy aspects of ubiquitous computing in the retail store of the future</a> at the 17th Conference on Computers, Freedom, and Privacy. </div>
  	  </div>    	    	    	    
  	  <div class="row">
  		<div class="col-md-2"></div>
  		<div class="col-md-10 newsItem newsNext">Prof. Kevin Fu explains laboratory research in <a target="_blank" href="http://www.bos.frb.org/economic/cprc/conferences/2007/contactless/index.htm">RFID security at the Emerging Payments Research Group Contactless Forum at the Boston Federal Reserve</a>. </div>
  	  </div>    	    	    	    
  	  <div class="row">
  		<div class="col-md-2"></div>
  		<div class="col-md-10 newsItem">Prof. Kevin Fu joins panelists at the TransAtlantic Consumer Dialogue&rsquo;s workshop on &ldquo;RFID and Ubiquitous Computing&quot; in Brussels, Belgium to discuss how  privacy and security can be built into the technology. </div>
  	  </div>    	    	    	    
  	  <div class="row">
  		<div class="col-md-2"></div>
  		<div class="col-md-10 newsItem newsNext"> The New York Times reports on SPQR researchers demonstrating <a target="_blank" href="http://www.nytimes.com/2006/10/23/business/23card.html">security and privacy vulnerabilities in RFID-enabled credit cards</a></div>
  	  </div>    	    	    	    
  	  <div class="row">
  		<div class="col-md-2"></div>
  		<div class="col-md-10 newsItem">SPQR researchers receive <a target="_blank" href="http://www.rfidjournal.com/article/articleview/2642/1/1/">$1.1 million from the National Science Foundation</a> to research cryptographic protocols, hardware and applications in RFID security. </div>
  	  </div>    	    	    	    
  	  <div class="row">
  		<div class="col-md-2 newsNext newsNext"><h2>By the Numbers</h2></div>
  		<div class="col-md-10"></div>
  	  </div>     	    	    	    	  
  	  <div class="row">
  		<div class="col-md-2"></div>
  		<div class="col-md-10 newsItem">4 Paper Awards (ACM SIGCOMM 2011, IEEE S&amp;P 2008, USENIX Security 2006, USENIX Security 2001)</div>
  	  </div>      	  
  	  <div class="row">
  		<div class="col-md-2"></div>
  		<div class="col-md-10 newsItem newsNext">2 IEEE Fellows</div>
  	  </div>   
  	  <div class="row">
  		<div class="col-md-2"></div>
  		<div class="col-md-10 newsItem">5 Fellowships: <a target="_blank" href="http://www.sloan.org/fellowships">Sloan Research Fellowship</a>, <a target="_blank" href="http://www.intel.com/education/highered/studentprograms/fellowship.htm">Intel PhD Fellowship</a>,<a target="_blank" href="http://www.usenix.org/students/sweb/past.html">USENIX Scholars Fellowship</a>, 2 <a target="_blank" href="http://www.nsf.gov/funding/pgm_summ.jsp?pims_id=6201">NSF Graduate Research Fellowships</a></div>
  	  </div>     	  
  	  <div class="row">
  		<div class="col-md-2"></div>
  		<div class="col-md-10 newsItem newsNext">987 cups of espresso, 610 cups of coffee, 377 cups of tea (sort of)</div>
  	  </div>   
  	  <div class="row">
  		<div class="col-md-2"></div>
  		<div class="col-md-10 newsItem">5 <a target="_blank" href="images/future-researchers.png">future researchers</a></div>
  	  </div>     	    	  
  	    	    	       
  
      </div>   
      <hr class="featurette-divider">
      <!--<div class="watermark-title">NEWS & EVENTS</div> -->
      <!-- FOOTER -->
      <footer>
        <p class="pull-right"><a href="#">Back to top</a></p>
        <p>&copy; 2015 Security and Privacy Research Group - University of Michigan</p>
      </footer>

    </div><!-- /.container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
    <script src="dist/js/bootstrap.min.js"></script>
    <script src="docs-assets/js/holder.js"></script>
  </body>
</html>
