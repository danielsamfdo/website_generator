<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="keywords" content="">
    <!-- facebook -->
    <meta property="og:url" content="https://spqr.eecs.umich.edu/" />
	<meta property="og:site_name" content="SPQR - Security and Privacy Research Group" />
	<meta property="og:type" content="website" />
	<meta property="og:title" content="SPQR - Security and Privacy Research Group" />
	<meta property="og:image" content="http://localhost/spqr/images/SPQR-logo.jpg" />
	<meta property="og:description" content="" />

    <link rel="shortcut icon" href="images/spqr-favicon.png">

    <title>SPQR &mdash; Michigan EECS</title>

    <!-- Bootstrap core CSS -->
    <link href="dist/css/bootstrap.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy this line! -->
    <!--[if lt IE 9]><script src="../../docs-assets/js/ie8-responsive-file-warning.js"></script><![endif]-->

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->

    <!-- Custom styles for this template -->
    <link href="styles/bootstrap-spqr.css" rel="stylesheet">

  </head>  <body>
	    <div class="navbar-wrapper">
      <div class="container">

        <div class="navbar navbar-inverse navbar-static-top" role="navigation">
          <div class="container">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              <a class="navbar-brand" href="index.php">
              <div class="nav-header-logo">
                <script src="spqr.js"></script>
		<span onMouseOver="SPQRlink(this)">
              	<img src="images/SPQR-logo.jpg" class="nav-header-logo-img">
		</span>
              </div>
              <div class="nav-header-headline">Security and Privacy Research Group</div>
              <div class="nav-header-text">Computer Science & Engineering | University of Michigan</div> 
              </a>
            </div>
            <div class="navbar-collapse collapse">
              <ul class="nav navbar-nav">
               <li ><a href="index.php">HOME</a></li>
                <li  class="active" ><a href="people.php">PEOPLE</a></li>
                <li ><a href="publications.php">PUBLICATIONS</a></li>
                <li ><a href="projects.php">PROJECTS</a></li>
                <li ><a href="news.php">NEWS & EVENTS</a></li>
                <li ><a href="seminars.php">SEMINARS</a></li>
                <li ><a href="jobs.php">JOBS</a></li>
                <li ><a href="https://twitter.com/spqrfridge">SMART FRIDGE</a></li>
              </ul>
            </div>
          </div>
        </div>

      </div>
    </div>	<div class="container marketing">
      <div class="col-md-12 content-first-col">
      <h2>People</h2><br/>
        <h4>&nbsp;Faculty</h4>
        <div class="row">
  		<div class="col-md-3 peopleItem">
     	<div class="people">
     	  <div class="people-left">
     	  	<a href="http://web.eecs.umich.edu/~kevinfu/" target="_blank"><img class="img-circle" alt="Prof. Kevin Fu" src="images/kevin-fu.jpg"></a>
     	  </div>
     	  <div class="people-right">
          	<h5><span class="text-muted content-name"><a href="http://web.eecs.umich.edu/~kevinfu/" target="_blank">Prof. Kevin Fu</a></span></h5>
          </div>
        </div>
      </div>
      <div class="col-md-3 peopleItem">
        <div class="people">
        <div class="people-left">
          <a href="http://peter.honeyman.org/" target="_blank"><img class="img-circle" src="images/peter-honeyman.jpg"></a>
        </div>
        <div class="people-right">
            <h5><span class="text-muted content-name"><a href="http://peter.honeyman.org/" target="_blank">Prof. Peter Honeyman</a></span></h5>
          </div>
        </div>
      </div>
      </div>
      </div>  
 
 

       <div class="col-md-12 content-col">
        <h4>&nbsp;Ph.D. Students</h4> 
        <div class="row">
  		<div class="col-md-3 peopleItem">
     	<div class="people">
     	  <div class="people-left">
     	  	<img class="img-circle" src="images/sai-gouravajhala.jpg">     	  
     	  </div>
     	  <div class="people-right">
          	<h5><span class="text-muted content-name">Sai R. Gouravajhala</span></h5>
          </div>
        </div>
		</div>

        <div class="col-md-3 peopleItem">
     	<div class="people">
     	  <div class="people-left">
     	  	<img class="img-circle" src="images/no_photo.jpg">
     	  </div>
     	  <div class="people-right">
          	<h5><span class="text-muted content-name">Jeremy Erickson</span></h5>
          </div>
        </div>
        </div>

        <div class="col-md-3 peopleItem">
     	<div class="people">
     	  <div class="people-left">
     	  	<img class="img-circle" src="images/no_photo.jpg">
     	  </div>
     	  <div class="people-right">
          	<h5><span class="text-muted content-name">Tim Trippel</span></h5>
          </div>
        </div>
        </div>

        <div class="col-md-3 peopleItem">
     	<div class="people">
     	  <div class="people-left">
     	  	<img class="img-circle" src="images/ofir-weisse.jpg">
     	  </div>
     	  <div class="people-right">
          	<h5><span class="text-muted content-name"><a href="http://www.ofirweisse.com/">Ofir Weisse</a></span></h5>
          </div>
        </div>
        </div>


        </div>
      </div>             

       <div class="col-md-12 content-col">
        <h4>&nbsp;Masters Students</h4> 
        <div class="row">


      <div class="col-md-3 peopleItem">
      <div class="people">
        <div class="people-left">
          <img class="img-circle" src="images/aravind.jpg">
        </div>
        <div class="people-right">
            <h5><span class="text-muted content-name">Aravind Vadrevu</span></h5>
          </div>
        </div>
        </div>

        </div>
      </div>  

               
       <div class="col-md-12 content-col">
        <h4>&nbsp;Research Interns</h4>
      <div class="row">
        <div class="col-md-3 peopleItem">
      <div class="people">
        <div class="people-left">
          <img class="img-circle" src="images/evan-chavis.jpg">
        </div>
        <div class="people-right">
            <h5><span class="text-muted content-name">Evan Chavis<a href="http://echavisspqr.wordpress.com/" target="_blank"><img src="images/blog_icon.png"></a></span></h5>
          </div>
        </div>
        </div>
     
 
      </div> 
      </div>                  
        
       <div class="col-md-12 content-col">
        <h4>&nbsp;Staff</h4>
        <div class="row">
	<div class="col-md-3 peopleItem">      
     	<div class="people">
     	  <div class="people-left">
     	  	<img class="img-circle" src="images/no_photo.jpg">
     	  </div>
     	  <div class="people-right">
          	<h5><span class="text-muted content-name">Sarah Turner</span></h5>
          </div>
        </div>
      </div>   
      </div>
      </div>         
        
       <div class="col-md-12 content-col">
        <h4>&nbsp;Visitors and Affiliates</h4>
        <div class="row">
  		<div class="col-md-3 peopleItem">  
       	<div class="people">
     	  <div class="people-left">
     	  	<a href="http://vcsg.ecs.umass.edu/burleson.html" target="_blank"><img class="img-circle" src="images/wayne-burleson.jpg"></a>
     	  </div>
     	  <div class="people-right">
          	<h5><span class="text-muted content-name"><a href="http://vcsg.ecs.umass.edu/burleson.html" target="_blank">Prof. Wayne Burleson</a><br /><span class="content-name-sub">UMass Amherst</span></span></h5>
          </div>
        </div>
        </div>
        <div class="col-md-3 peopleItem">  
       	<div class="people">
     	  <div class="people-left">
     	  	<a href="http://en.wikipedia.org/wiki/Phil_Lapsley" target="_blank"><img class="img-circle" src="images/phil-lapsley.jpg"></a>
     	  </div>
     	  <div class="people-right">
          	<h5><span class="text-muted content-name"><a href="http://en.wikipedia.org/wiki/Phil_Lapsley" target="_blank">Phil Lapsley</a></span></h5>
          </div>
        </div>
        </div>
        <div class="col-md-3 peopleItem">  
       	<div class="people">
     	  <div class="people-left">
     	  	<a href="http://www.emsec.rub.de/chair/_staff/christof-paar/" target="_blank"><img class="img-circle" src="images/christof-paar.jpg"></a>
     	  </div>
     	  <div class="people-right">
          	<h5><span class="text-muted content-name"><a href="http://www.emsec.rub.de/chair/_staff/christof-paar/" target="_blank">Prof. Christof Paar</a><br /><span class="content-name-sub">Ruhr Universitat Bohum</span></span></h5>
          </div>
        </div>
        </div>
        <div class="col-md-3 peopleItem">  
       	<div class="people">
     	  <div class="people-left">
     	  	<a href="http://www.cse.sc.edu/~wyxu/" target="_blank"><img class="img-circle" src="images/wenyuan-xu.jpg"></a>
     	  </div>
     	  <div class="people-right">
          	<h5><span class="text-muted content-name"><a href="http://www.cse.sc.edu/~wyxu/" target="_blank">Prof. Wenyuan Xu</a><br /><span class="content-name-sub">Univ. South Carolina</span></span></h5>
          </div>
        </div>
		</div>
		</div>
    <div class="row">
   
      <div class="col-md-3 peopleItem">
      <div class="people">
        <div class="people-left">
          <a href="http://michaelrushanan.org/" target="_blank"><img class="img-circle" src="images/michael-rushanan.jpg"></a>
        </div>
        <div class="people-right">
            <h5><span class="text-muted content-name"><a href="http://michaelrushanan.org/" target="_blank">Michael Rushanan<br /></a><span class="content-name-sub">JHU</span></span></h5>
          </div>
        </div>
        </div>
      </div>  
      </div>                     
       <div class="col-md-12 content-col">
        <h4>&nbsp;Ph.D. Alums</h4>
        <div class="row">
  		<div class="col-md-3 peopleItem">  
     	<div class="people">
     	  <div class="people-left">
     	  	<a href="http://people.umass.edu/gbecker/" target="_blank"><img class="img-circle" src="images/georg-becker.jpg"></a>
     	  </div>
     	  <div class="people-right">
          	<h5><span class="text-muted content-name"><a href="http://people.umass.edu/gbecker/" target="_blank">Georg Becker</a></span></h5>
          </div>
        </div>
        </div>
        <div class="col-md-3 peopleItem"> 
     	<div class="people">
     	  <div class="people-left">
     	  	<img class="img-circle" src="images/shane-clark.jpg">
     	  </div>
     	  <div class="people-right">
          	<h5><span class="text-muted content-name"><a href="http://www.cs.umass.edu/~ssclark/" target="_blank">Shane S. Clark</a></span></h5>
          </div>
        </div>
        </div>
        <div class="col-md-3 peopleItem"> 
     	<div class="people">
     	  <div class="people-left">
     	  	<a href="http://people.umass.edu/ghinterw/" target="_blank"><img class="img-circle" src="images/gesine-hinterwaelder.jpg"></a>
     	  </div>
     	  <div class="people-right">
          	<h5><span class="text-muted content-name"><a href="http://people.umass.edu/ghinterw/" target="_blank">Gesine Hinterwälder</a></span></h5>
          </div>
        </div>  
        </div>

  		<div class="col-md-3 peopleItem"> 
     	<div class="people">
     	  <div class="people-left">
     	  	<a href="http://people.umass.edu/lang/" target="_blank"><img class="img-circle" src="images/lang-lin.jpg"></a>
     	  </div>
     	  <div class="people-right">
          	<h5><span class="text-muted content-name"><a href="http://people.umass.edu/lang/" target="_blank">Lang Lin</a></span></h5>
          </div>
        </div>
        </div>        

        </div>
        
                
        
        <div class="row">

    	<div class="col-md-3 peopleItem"> 
     	<div class="people">
     	  <div class="people-left">
     	  	<a href="http://cs.dartmouth.edu/~amolina/Andres_Molina-Markham/Home.html" target="_blank"><img class="img-circle" src="images/andres-molina.jpg"></a>
     	  </div>
     	  <div class="people-right">
          	<h5><span class="text-muted content-name"><a href="http://cs.dartmouth.edu/~amolina/Andres_Molina-Markham/Home.html" target="_blank">Andres Molina-Markham</a></span></h5>
          </div>
        </div>
        </div>
        <div class="col-md-3 peopleItem"> 
     	<div class="people">
     	  <div class="people-left">
     	  	<a href="https://homes.cs.washington.edu/~ransford/" target="_blank"><img class="img-circle" src="images/ransford.jpg"></a>
     	  </div>
     	  <div class="people-right">
          	<h5><span class="text-muted content-name"><a href="https://homes.cs.washington.edu/~ransford/" target="_blank">Benjamin Ransford</a></span></h5>
          </div>
        </div>
        </div>
        
        
  		<div class="col-md-3 peopleItem"> 
     	<div class="people">
     	  <div class="people-left">
     	  	<a href="http://www.cs.virginia.edu/~ms6bf/Home.html" target="_blank"><img class="img-circle" src="images/negin2.png"></a>
     	  </div>
     	  <div class="people-right">
          	<h5><span class="text-muted content-name"><a href="http://www.cs.virginia.edu/~ms6bf/Home.html" target="_blank">Mastooreh Salajegheh</a></span></h5>
          </div>
        </div>
        </div>
        </div>

      </div>          

       <div class="col-md-12 content-col">
        <h4>&nbsp;Postdoctoral Researcher Alums</h4>
        
       <div class="row">

      <div class="col-md-3 peopleItem">
      <div class="people">
        <div class="people-left">
          <a href="http://www.cs.umass.edu/~foo/" target="_blank"><img class="img-circle" alt="Generic placeholder image" src="images/denis-fookune.jpg"></a>
        </div>
        <div class="people-right">
            <h5><span class="text-muted content-name"><a href="http://www.cs.umass.edu/~foo/" target="_blank">Dr. Denis Foo Kune<br /></a><span class="content-name-sub">Univ. MN</span></span></h5>
          </div>  
        </div>      
      </div>


  		<div class="col-md-3 peopleItem">
  		  <div class="people">
     	  <div class="people-left">
     	  	<a href="http://www.impedimenttoprogress.com/" target="_blank"><img class="img-circle" src="images/matthew-hicks.jpg"></a>
     	  </div>
     	  <div class="people-right">
          	<h5><span class="text-muted content-name"><a href="http://www.impedimenttoprogress.com/" target="_blank">Dr. Matthew Hicks</a><br><span class="content-name-sub">Illinois</span></span></h5>
          </div>
        </div>
  		</div>
  		<div class="col-md-3 peopleItem">
  		   	<div class="people">
     	  <div class="people-left">
     	  	<a href="http://www.eecs.berkeley.edu/~holcomb/Site/home.html" target="_blank"><img class="img-circle" src="images/dan-holcomb.jpg"></a>
     	  </div>
     	  <div class="people-right">
          	<h5><span class="text-muted content-name"><a href="http://www.eecs.berkeley.edu/~holcomb/Site/home.html" target="_blank">Dr. Dan Holcomb</a><br /><span class="content-name-sub">UC Berkeley</span></span></h5>
          </div>
        </div>
  		</div>
  		<div class="col-md-3 peopleItem">
  		  	<div class="people">
     	  <div class="people-left">
     	  	<a href="http://www-personal.umich.edu/~cmswnsn/" target="_blank"><img class="img-circle" src="images/colleen-swanson.jpg"></a>     	 
     	  </div>
     	  <div class="people-right">
          	<h5><span class="text-muted content-name"><a href="http://www-personal.umich.edu/~cmswnsn/" target="_blank">Dr. Colleen Swanson</a><br /><span class="content-name-sub">U. Waterloo</span></span></h5>
          </div>
        </div>
  		</div>
  	  </div>
      </div>



       <div class="col-md-12 content-col">
        <h4>&nbsp;Masters Alums</h4>

        <div class="row">
        <div class="col-md-3 peopleItem"> 
     	<div class="people">
     	  <div class="people-left">
     	  	<img class="img-circle" src="images/hee-jin.jpg">
     	  </div>
     	  <div class="people-right">
          	<h5><span class="text-muted content-name">Hee-Jin Chae</span></h5>
          </div>
        </div>
        </div>

        <div class="col-md-3 peopleItem"> 
     	<div class="people">
     	  <div class="people-left">
     	  	<img class="img-circle" src="images/benessa-defend.jpg">
     	  </div>
     	  <div class="people-right">
          	<h5><span class="text-muted content-name">Benessa Defend</span></h5>
          </div>
        </div>
        </div>

  		<div class="col-md-3 peopleItem"> 
     	<div class="people">
     	  <div class="people-left">
     	  	<a href="http://people.cs.umass.edu/~sguineau/" target="_blank"><img class="img-circle" src="images/shane-guineau.jpg"></a>
     	  </div>
     	  <div class="people-right">
          	<h5><span class="text-muted content-name"><a href="http://people.cs.umass.edu/~sguineau/" target="_blank">Shane Guineau</a></span></h5>
          </div>
        </div>
        </div>


        <div class="col-md-3 peopleItem"> 
     	<div class="people">
     	  <div class="people-left">
     	  	<img class="img-circle" src="images/tom-heydt-benjamin.jpg">
     	  </div>
     	  <div class="people-right">
          	<h5><span class="text-muted content-name">Thomas S. Heydt-Benjamin</span></h5>
          </div>
        </div>
        </div>


        </div>
        
        
        
        
        <div class="row">

        <div class="col-md-3 peopleItem"> 	
     	<div class="people">
     	  <div class="people-left">
     	  	<a href="http://www.eecs.berkeley.edu/~holcomb/Site/home.html" target="_blank"><img class="img-circle" src="images/dan-holcomb.jpg"></a>
     	  </div>
     	  <div class="people-right">
          	<h5><span class="text-muted content-name"><a href="http://www.eecs.berkeley.edu/~holcomb/Site/home.html" target="_blank">Dan Holcomb</a></span></h5>
          </div>
        </div>
        </div>


        <div class="col-md-3 peopleItem"> 
     	<div class="people">
     	  <div class="people-left">
     	  	<img class="img-circle" src="images/lychev.jpg">
     	  </div>
     	  <div class="people-right">
          	<h5><span class="text-muted content-name">Robert Lychev</span></h5>
          </div>
        </div>
        </div>


        <div class="col-md-3 peopleItem"> 
     	<div class="people">
     	  <div class="people-left">
     	  	<img class="img-circle" src="images/no_photo.jpg">
     	  </div>
     	  <div class="people-right">
          	<h5><span class="text-muted content-name">Mike Todd</span></h5>
          </div>
        </div>
        </div>

      <div class="col-md-3 peopleItem">
      <div class="people">
        <div class="people-left">
          <img class="img-circle" src="images/joelvdw.jpg">
        </div>
        <div class="people-right">
            <h5><span class="text-muted content-name">Joel Van Der Woude<a href="http://joelspqr.wordpress.com/"><img src="images/blog_icon.png"></a></span></h5>
          </div>
        </div>
        </div>


        <div class="col-md-3 peopleItem"> 
     	<div class="people">
     	  <div class="people-left">
     	  	<a href="http://www.cs.umass.edu/~zhangh/" target="_blank"><img class="img-circle" src="images/hongzhang.jpg"></a>
     	  </div>
     	  <div class="people-right">
          	<h5><span class="text-muted content-name"><a href="http://www.cs.umass.edu/~zhangh/" target="_blank">Hong Zhang</a></span></h5>
          </div>
        </div>
        </div>

        <div class="col-md-3 peopleItem"> 
     	<div class="people">
     	  <div class="people-left">
     	  	<img class="img-circle" src="images/serge-zhilyaev.jpg">
     	  </div>
     	  <div class="people-right">
          	<h5><span class="text-muted content-name">Serge Zhilyaev</span></h5>
          </div>
        </div>
        </div>


        </div>


      </div>          


        
       <div class="col-md-12 content-col">
        <h4>&nbsp;Research Assistant Alums</h4>
                 <div class="row">
      <div class="col-md-3 peopleItem">
      <div class="people">
        <div class="people-left">
          <img class="img-circle" src="images/miran-alhaideri.jpg">
        </div>
        <div class="people-right">
            <h5><span class="text-muted content-name">Miran Alhaideri<a href="http://miranspqr.wordpress.com/" target="_blank"><img src="images/blog_icon.png"></a></span></h5>
          </div>
        </div>
        </div>
        <div class="col-md-3 peopleItem">
      <div class="people">
        <div class="people-left">
          <img class="img-circle" src="images/vishal-joshi.jpg">
        </div>
        <div class="people-right">
            <h5><span class="text-muted content-name">Vishal Joshi<a href="http://vmjspqr.blogspot.com/" target="_blank"><img src="images/blog_icon.png"></a></span></h5>
          </div>
        </div>
        </div>
        <div class="col-md-3 peopleItem">
      <div class="people">
        <div class="people-left">
          <img class="img-circle" src="images/noah-klugman.jpg">
        </div>
        <div class="people-right">
            <h5><span class="text-muted content-name">Noah Klugman<img src="images/blog_icon.png"></a></span></h5>
          </div>
        </div>
        </div>
        <div class="col-md-3 peopleItem">
      <div class="people">
        <div class="people-left">
          <img class="img-circle" src="images/thomas-lovett.jpg">
        </div>
        <div class="people-right">
            <h5><span class="text-muted content-name">Thomas Lovett<a href="http://tklovett.com/" target="_blank"><img src="images/blog_icon.png"></a></span></h5>
          </div>
        </div>
        </div>
        </div>
        <div class="row">
  		<div class="col-md-3 peopleItem"> 
     	<div class="people">
     	  <div class="people-left">
     	  	<img class="img-circle" src="images/teresa-fiore.jpg">
     	  </div>
     	  <div class="people-right">
          	<h5><span class="text-muted content-name">Teresa Fiore</span></h5>
          </div>
        </div>
        </div>
        <div class="col-md-3 peopleItem"> 
     	<div class="people">
     	  <div class="people-left">
     	  	<img class="img-circle" src="images/andrew-hall.jpg">
     	  </div>
     	  <div class="people-right">
          	<h5><span class="text-muted content-name">Andrew Hall</span></h5>
          </div>
        </div>
        </div>
        <div class="col-md-3 peopleItem"> 
     	<div class="people">
     	  <div class="people-left">
     	  	<img class="img-circle" src="images/no_photo.jpg">
     	  </div>
     	  <div class="people-right">
          	<h5><span class="text-muted content-name">Nicole Kaufman <span class="content-name-sub">Summer 2011</span></span></h5>
          </div>
        </div>
        </div>
        <div class="col-md-3 peopleItem"> 
     	<div class="people">
     	  <div class="people-left">
     	  	<a href="http://www.cs.umass.edu/~korobova/" target="_blank"><img class="img-circle" src="images/olga-korobova.jpg"></a>
     	  </div>
     	  <div class="people-right">
          	<h5><span class="text-muted content-name"><a href="http://www.cs.umass.edu/~korobova/" target="_blank">Olga Korobova</a></span></h5>
          </div>
        </div>
        </div>
        </div>
        <div class="row">
  		<div class="col-md-3 peopleItem"> 
     	<div class="people">
     	  <div class="people-left">
     	  	<a href="http://nfcsec.blogspot.com/" target="_blank"><img class="img-circle" src="images/erin-mcbride.png"></a>
     	  </div>
     	  <div class="people-right">
          	<h5><span class="text-muted content-name"><a href="http://nfcsec.blogspot.com/" target="_blank">Erin McBride</a><br /><span class="content-name-sub">Summer 2011</span></span></h5>
          </div>
        </div>
        </div>
        <div class="col-md-3 peopleItem"> 
     	<div class="people">
     	  <div class="people-left">
     	  	<img class="img-circle" src="images/quinn-stewart.jpg">
     	  </div>
     	  <div class="people-right">
          	<h5><span class="text-muted content-name">Quinn Stewart</span></h5>
          </div>
        </div>
        </div>

      <div class="col-md-3 peopleItem">
      <div class="people">
        <div class="people-left">
          <img class="img-circle" src="images/adam-norton.jpg">
        </div>
        <div class="people-right">
            <h5><span class="text-muted content-name">Adam Norton<a href="http://spqr-atnorton.blogspot.com/" target="_blank"><img src="images/blog_icon.png"></a></span></h5>
          </div>
        </div>
        </div>
        <div class="col-md-3 peopleItem">
      <div class="people">
        <div class="people-left">
          <img class="img-circle" src="images/kasia-olejnik.jpg">
        </div>
        <div class="people-right">
            <h5><span class="text-muted content-name">Katarzyna Olejnik<a href="http://kasiaspqr.wordpress.com/" target="_blank"><img src="images/blog_icon.png"></a></span></h5>
          </div>
        </div>
        </div>

        <div class="col-md-3 peopleItem">
      <div class="people">
        <div class="people-left">
          <img class="img-circle" src="images/spencer-kim.jpg">
        </div>
        <div class="people-right">
            <h5><span class="text-muted content-name"><a href="http://eecs.umich.edu/~spegkim/" target="_blank">Spencer Kim</a><a href="http://spegkim.blogspot.com" target="_blank"><img src="images/blog_icon.png"></a></span></h5>
          </div>
        </div>
        </div>
        <div class="col-md-3 peopleItem">
      <div class="people">
        <div class="people-left">
          <img class="img-circle" src="images/nicholas-terrell.jpg">
        </div>
        <div class="people-right">
            <h5><span class="text-muted content-name">Nicholas Terrell <a href="http://nickspqr.blogspot.com/" target="_blank"><img src="images/blog_icon.png"></a></span></h5>
          </div>
        </div>
        </div>

        <div class="col-md-3 peopleItem">
      <div class="people">
        <div class="people-left">
          <img class="img-circle" src="images/qiyu-hu.jpg">
        </div>
        <div class="people-right">
            <h5><span class="text-muted content-name">Qiyu Hu<a href="http://qiyuhspqr.blogspot.com/" target="_blank"><img src="images/blog_icon.png"></a></span></h5>
          </div>
        </div>
        </div>

        </div>
        
      </div>                  
      <hr class="featurette-divider">
      <!--<div class="watermark-title">PEOPLE</div> -->
      <!-- FOOTER -->
      <footer>
        <p class="pull-right"><a href="#">Back to top</a></p>
        <p>&copy; 2015 Security and Privacy Research Group - University of Michigan</p>
      </footer>

    </div><!-- /.container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
    <script src="dist/js/bootstrap.min.js"></script>
    <script src="docs-assets/js/holder.js"></script>
  </body>
</html>
