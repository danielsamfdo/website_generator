<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
	"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
	<title>SPQR &mdash; UMass Amherst Computer Science &mdash; Publications</title>
    <link rel="stylesheet" type="text/css"
		href="//fonts.googleapis.com/css?family=Yanone+Kaffeesatz:300|Tinos:regular,bold" />
	<link rel="stylesheet" type="text/css" href="style/spqr-screen.css" />
	<link rel="stylesheet" type="text/css" href="style/spqr-pubs.css" />
	<link rel="icon" type="image/png" href="images/spqr-favicon.png" />

	<meta name="description" content="Security and privacy research at the
	University of Massachusetts Amherst" />
	<script type="text/JavaScript" src="spqr.js"></script>
</head>
<body>
<div id="main">

<div id="topmatter">
	<h1 onMouseOver="SPQRlink(this)"><img src="images/SPQR.png" align="left" alt="SPQR Laboratory" hspace="20">Security and Privacy Research Lab</h1><h3><a href="http://www.cs.umass.edu/">Department of Computer Science</a><br /><a href="http://www.umass.edu/">University of Massachusetts Amherst</a></h3>
</div> <!-- /topmatter -->


<div id="breadcrumbs">
   <h1>	<a href="/">Home</a> &nbsp; &nbsp;
	<a href="/people.php">People</a> &nbsp; &nbsp;
	<a href="/publications.php">Publications</a> &nbsp; &nbsp;
	<a href="/projects.php">Projects</a> &nbsp; &nbsp;
        <a href="/news.php">News &amp; Events</a> &nbsp; &nbsp;
	<a href="/seminars.php">Seminars</a> &nbsp; &nbsp;
	<a href="/jobs.php">Jobs</a> 
</h1>
</div>

<!-- vim: set noet ts=4 sw=4 ft=html tw=80: -->

<div id="meat">

<div id="spqrpubs">



<dl>

<dt>
[<a name="Kotz:2015:SMC:2808213.2790830">KFGR15</a>]
</dt>
<dd>
David Kotz, Kevin Fu, Carl Gunter, and Avi Rubin.
 Security for mobile and cloud frontiers in healthcare.
 <em>Communications of the ACM</em>, 58(8):21&ndash;23, July 2015.
[&nbsp;<a href="spqrbib_bib.html#Kotz:2015:SMC:2808213.2790830">bib</a>&nbsp;| 
<a href="http://doi.acm.org/10.1145/2790830">http</a>&nbsp;]

</dd>


<dt>
[<a name="rahmati-isca2015">RHHF15</a>]
</dt>
<dd>
Amir Rahmati, Matthew Hicks, Daniel&nbsp;E. Holcomb, and Kevin Fu.
 Probable cause: The deanonymizing effects of approximate DRAM.
 In <em>Proceedings of the 42nd International Symposium of Computer
  Architecture (ISCA)</em>, Portland, OR, June 2015.
[&nbsp;<a href="spqrbib_bib.html#rahmati-isca2015">bib</a>&nbsp;]

</dd>


<dt>
[<a name="6781658">LRH<sup>+</sup>14</a>]
</dt>
<dd>
E.A. Lee, J.&nbsp;Rabaey, B.&nbsp;Hartmann, J.&nbsp;Kubiatowicz, K.&nbsp;Pister,
  A.&nbsp;Sangiovanni-Vincentelli, S.A. Seshia, J.&nbsp;Wawrzynek, D.&nbsp;Wessel, T.S.
  Rosing, D.&nbsp;Blaauw, P.&nbsp;Dutta, K.&nbsp;Fu, C.&nbsp;Guestrin, B.&nbsp;Taskar, R.&nbsp;Jafari,
  D.&nbsp;Jones, V.&nbsp;Kumar, R.&nbsp;Mangharam, G.J. Pappas, R.M. Murray, and A.&nbsp;Rowe.
 The swarm at the edge of the cloud.
 <em>Design Test, IEEE</em>, 31(3):8&ndash;20, June 2014.
[&nbsp;<a href="spqrbib_bib.html#6781658">bib</a>&nbsp;| 
<a href="http://chess.eecs.berkeley.edu/pubs/1066/LeeEtAl_TerraSwarm_DesignAndTest.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: 
</font></blockquote>

</dd>


<dt>
[<a name="hicks-asplos2015">HSKS15</a>]
</dt>
<dd>
Matthew Hicks, Cynthia Sturton, Samuel&nbsp;T. King, and Jonathan&nbsp;M. Smith.
 SPECS: A lightweight runtime mechanism for protecting software from
  security-critical processor bugs.
 In <em>Proceedings of the 20th International Conference on
  Architectural Support for Programming Languages and Operating Systems
  (ASPLOS)</em>, ASPLOS '15, March 2015.
[&nbsp;<a href="spqrbib_bib.html#hicks-asplos2015">bib</a>&nbsp;| 
<a href="http://www.impedimenttoprogress.com/storage/publications/hicks_ASPLOS_15.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Security, Hardware, Architecture
</font></blockquote>

</dd>


<dt>
[<a name="holcomb:ches2014bitline">HF14a</a>]
</dt>
<dd>
Daniel&nbsp;E Holcomb and Kevin Fu.
 Bitline PUF: Building Native Challenge-Response PUF Capability into
  Any SRAM.
 In Lejla Batina and Matthew Robshaw, editors, <em>Cryptographic
  Hardware and Embedded Systems (CHES 2014)</em>, volume 8731 of <em>Lecture Notes
  in Computer Science</em>, pages 510&ndash;526, September 2014.
[&nbsp;<a href="spqrbib_bib.html#holcomb:ches2014bitline">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/holcomb_bitline_ches14.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: PUF, Security, Hardware, Circuits
</font></blockquote>

</dd>


<dt>
[<a name="holcomb-wacas2014">HF14b</a>]
</dt>
<dd>
Daniel&nbsp;E. Holcomb and Kevin Fu.
 QBF-based synthesis of optimal word-splitting in approximate
  multi-level storage cells.
 In <em>Workshop on Approximate Computing Across the System Stack
  (WACAS)</em>, Salt Lake City, UT, March 2014.
[&nbsp;<a href="spqrbib_bib.html#holcomb-wacas2014">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/holcomb_qbf_wacas14.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Hardware, Approximate Storage, QBF, Flash, MLC
</font></blockquote>

</dd>


<dt>
[<a name="rushanan-sok2014">RFKSR14</a>]
</dt>
<dd>
Michael Rushanan, Denis Foo&nbsp;Kune, Colleen&nbsp;M. Swanson, and Aviel&nbsp;D. Rubin.
 Sok: Security and privacy in implantable medical devices and body
  area networks.
 In <em>Proceedings of the 35th Annual IEEE Symposium on Security and
  Privacy</em>, May 2014.
[&nbsp;<a href="spqrbib_bib.html#rushanan-sok2014">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/rushanan-sok-oakland14.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Security, Privacy, Health
</font></blockquote>

</dd>


<dt>
[<a name="rahmati-wacas2014">RHHF14</a>]
</dt>
<dd>
Amir Rahmati, Matthew Hicks, Daniel&nbsp;E. Holcomb, and Kevin Fu.
 Refreshing thoughts on DRAM: Power saving vs. data integrity.
 In <em>Workshop on Approximate Computing Across the System Stack
  (WACAS)</em>, Salt Lake City, UT, March 2014.
[&nbsp;<a href="spqrbib_bib.html#rahmati-wacas2014">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/dram/rahmati-wacas14.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Hardware, DRAM
</font></blockquote>

</dd>


<dt>
[<a name="ruhrmair-14">RH14</a>]
</dt>
<dd>
Ulrich Ruhrmair and Daniel&nbsp;E. Holcomb.
 PUFs at a Glance.
 In <em>Proceedings of Design Automation and Test in Europe (DATE
  '14)</em>, March 2014.
[&nbsp;<a href="spqrbib_bib.html#ruhrmair-14">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/holcomb_PUFs_date14.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Hardware, PUF
</font></blockquote>

</dd>


<dt>
[<a name="go2014retransmissiongsm">GWFK<sup>+</sup>14</a>]
</dt>
<dd>
Younghwan Go, Jongil Won, Denis Foo&nbsp;Kune, EunYoung Jeong, Yongdae Kim, and
  KyoungSoo Park.
 Gaining control of cellular traffic accounting by spurious tcp
  retransmission.
 In <em>In Proceedings of the Network and Distributed System Security
  Symposium</em>, February 2014.
[&nbsp;<a href="spqrbib_bib.html#go2014retransmissiongsm">bib</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Wireless, Mobile, Networking
</font></blockquote>

</dd>


<dt>
[<a name="fu:-cacm">FB13</a>]
</dt>
<dd>
Kevin Fu and James Blum.
 Inside risks: Controlling for cybersecurity risks of medical device
  software.
 <em>Communications of the ACM</em>, 56(10):21&ndash;23, October 2013.
[&nbsp;<a href="spqrbib_bib.html#fu:-cacm">bib</a>&nbsp;| 
<a href="http://www.csl.sri.com/users/neumann/cacm231.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Health, Security, Privacy
</font></blockquote>

</dd>


<dt>
[<a name="Fu:House:2012">Fu12</a>]
</dt>
<dd>
Kevin Fu.
 On the expectations of smart cards to reduce Medicare fraud,
  November 2012.
 Testimony to the Subcommittee on Health, Committee on Energy and
  Commerce, United States House of Representatives, Hearing on Examining
  Options to Combat Health Care Waste, Fraud and Abuses, Wednesday, November
  28, 2012.
[&nbsp;<a href="spqrbib_bib.html#Fu:House:2012">bib</a>&nbsp;| 
<a href="http://energycommerce.house.gov/sites/republicans.energycommerce.house.gov/files/Hearings/Health/20121128/HHRG-112-IF14-WState-FuK-20121128.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Health, Security
</font></blockquote>

</dd>


<dt>
[<a name="fookune-emi2013">FKBC<sup>+</sup>13</a>]
</dt>
<dd>
Denis Foo&nbsp;Kune, John Backes, Shane&nbsp;S. Clark, Daniel&nbsp;B. Kramer, Matthew&nbsp;R.
  Reynolds, Kevin Fu, Yongdae Kim, and Wenyuan Xu.
 Ghost talk: Mitigating EMI signal injection attacks against analog
  sensors.
 In <em>Proceedings of the 34th Annual IEEE Symposium on Security and
  Privacy</em>, May 2013.
[&nbsp;<a href="spqrbib_bib.html#fookune-emi2013">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/fookune-emi-oakland13.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Security, Privacy, Health, EMI
</font></blockquote>

</dd>


<dt>
[<a name="fookune:hotmobile13">GFKPK13</a>]
</dt>
<dd>
Younghwan Go, Denis Foo&nbsp;Kune, KyoungSoo Park, and Yongdae Kim.
 Towards accurate accounting of cellular data for tcp retransmission.
 In <em>Fourteenth Workshop on Mobile Computing Systems and
  Applications (ACM HotMobile 2013)</em>, February 2013.
[&nbsp;<a href="spqrbib_bib.html#fookune:hotmobile13">bib</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Wireless, Mobile, Networking
</font></blockquote>

</dd>


<dt>
[<a name="salajegheh-phd">Sal12</a>]
</dt>
<dd>
Mastooreh Salajegheh.
 <em>Software Techniques to Reduce the Energy Consumption of
  Low-Power Devices at the Limits of Digital Abstractions</em>.
 PhD thesis, University of Massachusetts Amherst, September 2012.
[&nbsp;<a href="spqrbib_bib.html#salajegheh-phd">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/salajegheh-thesis.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Thesis, Probabilistic Storage, Power Management
</font></blockquote>

</dd>


<dt>
[<a name="clark-currentevents-techreport">CRS<sup>+</sup>12</a>]
</dt>
<dd>
Shane&nbsp;S. Clark, Benjamin Ransford, Jacob Sorber, Wenyuan Xu, Erik
  Learned-Miller, and Kevin Fu.
 Current Events: Identifying webpages by tapping the electrical
  outlet.
 Technical Report UM-CS-2011-030, Department of Computer Science,
  University of Massachusetts Amherst, Amherst, MA, July 2012.
[&nbsp;<a href="spqrbib_bib.html#clark-currentevents-techreport">bib</a>&nbsp;| 
<a href="https://web.cs.umass.edu/publication/details.php?id=2147">http</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Side Channels, Privacy, Power Analysis
</font></blockquote>

</dd>


<dt>
[<a name="molinamarkham:fc12">MMDF<sup>+</sup>12</a>]
</dt>
<dd>
Andres Molina-Markham, George Danezis, Kevin Fu, Prashant Shenoy, and David
  Irwin.
 Designing privacy-preserving smart meters with low-cost
  microcontrollers.
 In <em>Proceedings of the 16th International Conference on Financial
  Cryptography and Data Security</em>, FC '12, February 2012.
[&nbsp;<a href="spqrbib_bib.html#molinamarkham:fc12">bib</a>&nbsp;| 
<a href="http://eprint.iacr.org/2011/544.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Privacy-preserving, Microcontrollers, Zero-knowledge, Meters
</font></blockquote>

</dd>


<dt>
[<a name="clark:mobihealth11">CF11</a>]
</dt>
<dd>
Shane&nbsp;S. Clark and Kevin Fu.
 Recent results in computer security for medical devices.
 In <em>International ICST Conference on Wireless Mobile
  Communication and Healthcare (MobiHealth), Special Session on Advances in
  Wireless Implanted Devices</em>, October 2011.
[&nbsp;<a href="spqrbib_bib.html#clark:mobihealth11">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/clark-mobihealth11.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Security, Health
</font></blockquote>

</dd>


<dt>
[<a name="salajegheh-tecs2013">SWJ<sup>+</sup>13</a>]
</dt>
<dd>
Mastooreh Salajegheh, Yue Wang, Anxiao&nbsp;(Andrew) Jiang, Erik Learned-Miller, and
  Kevin Fu.
 Half-wits: Software techniques for low-voltage probabilistic storage
  on microcontrollers with NOR flash memory.
 <em>ACM Transactions on Embedded Computing Systems, Special Issue on
  Probabilistic Embedded Computing</em>, 12(2s), May 2013.
[&nbsp;<a href="spqrbib_bib.html#salajegheh-tecs2013">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/salajegheh-tecs13.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Probabilistic Storage, Power Management, Journal Paper
</font></blockquote>

</dd>


<dt>
[<a name="Zhang:Ekho:HotPower2011">ZSFS11</a>]
</dt>
<dd>
Hong Zhang, Mastooreh Salajegheh, Kevin Fu, and Jacob Sorber.
 Ekho: Bridging the gap between simulation and reality in tiny
  energy-harvesting sensors.
 In <em>Workshop on Power Aware Computing and Systems (HotPower
  2011)</em>, October 2011.
[&nbsp;<a href="spqrbib_bib.html#Zhang:Ekho:HotPower2011">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/zhang-ekho-hotpower11.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: RFID, Power Management, Hardware
</font></blockquote>

</dd>


<dt>
[<a name="hanna-healthsec11">HRMM<sup>+</sup>11</a>]
</dt>
<dd>
Steve Hanna, Rolf Rolles, Andres Molina-Markham, Pongsin Poosankam, Kevin Fu,
  and Dawn Song.
 Take two software updates and see me in the morning: The case for
  software security evaluations of medical devices.
 In <em>Proceedings of 2nd USENIX Workshop on Health Security and
  Privacy (HealthSec)</em>, August 2011.
[&nbsp;<a href="spqrbib_bib.html#hanna-healthsec11">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/hanna-aed-healthsec11.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Security, Health
</font></blockquote>

</dd>


<dt>
[<a name="Gollakota-IMD:SIGCOMM2011">GHR<sup>+</sup>11</a>]
</dt>
<dd>
Shyamnath Gollakota, Haitham Hassanieh, Benjamin Ransford, Dina Katabi, and
  Kevin Fu.
 They can hear your heartbeats: Non-invasive security for implanted
  medical devices.
 In <em>Proceedings of ACM SIGCOMM</em>, August 2011.
[&nbsp;<a href="spqrbib_bib.html#Gollakota-IMD:SIGCOMM2011">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/gollakota-SIGCOMM11-IMD.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Wireless, Health, Security, Award Paper
</font></blockquote>

</dd>


<dt>
[<a name="Fu:Senate:2011">Fu11a</a>]
</dt>
<dd>
Kevin Fu.
 Software issues for the medical device approval process, April 2011.
 Statement to the Special Committee on Aging, United States Senate,
  Hearing on a delicate balance: FDA and the reform of the medical device
  approval process, Wednesday, April 13, 2011.
[&nbsp;<a href="spqrbib_bib.html#Fu:Senate:2011">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/fu-senate-comm-aging-med-dev-sw-apr-2011.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Health, Security
</font></blockquote>

</dd>


<dt>
[<a name="salajegheh-fast2011">SWF<sup>+</sup>11</a>]
</dt>
<dd>
Mastooreh Salajegheh, Yue Wang, Kevin Fu, Anxiao&nbsp;(Andrew) Jiang, and Erik
  Learned-Miller.
 Exploiting half-wits: Smarter storage for low-power devices.
 In <em>Proceedings of the 9th USENIX Conference on File and Storage
  Technologies (FAST '11)</em>, San Jose, CA, February 2011.
[&nbsp;<a href="spqrbib_bib.html#salajegheh-fast2011">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/salajegheh-halfwits-FAST11.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Probabilistic Storage, Power Management
</font></blockquote>

</dd>


<dt>
[<a name="Chae-WISP-2012">CSY<sup>+</sup>12</a>]
</dt>
<dd>
Hee-Jin Chae, Mastooreh Salajegheh, Daniel&nbsp;J. Yeager, Joshua&nbsp;R. Smith, and
  Kevin Fu.
 <em>Wirelessly Powered Sensor Networks and Computational RFID</em>,
  chapter Maximalist Cryptography and Computation on the WISP UHF RFID
  Tag.
 Springer, 2012.
 An earlier version based on older WISP technology appeared in
  RFIDSec07.
[&nbsp;<a href="spqrbib_bib.html#Chae-WISP-2012">bib</a>&nbsp;| 
<a href="http://www.springer.com/engineering/signals/book/978-1-4419-6165-5">http</a>&nbsp;]
<blockquote><font size="-1">
Keywords: RFID, Crypto, Security
</font></blockquote>

</dd>


<dt>
[<a name="fu-IOM-trustworthy-med-sw-2011">Fu11b</a>]
</dt>
<dd>
Kevin Fu.
 Trustworthy medical device software.
 In <em>Public Health Effectiveness of the FDA 510(k) Clearance
  Process: Measuring Postmarket Performance and Other Select Topics: Workshop
  Report</em>, Washington, DC, July 2011.
 IOM (Institute of Medicine), National Academies Press.
[&nbsp;<a href="spqrbib_bib.html#fu-IOM-trustworthy-med-sw-2011">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/fu-trustworthy-medical-device-software-IOM11.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Health
</font></blockquote>

</dd>


<dt>
[<a name="ransford-mementos-tr">RSF10</a>]
</dt>
<dd>
Benjamin Ransford, Jacob Sorber, and Kevin Fu.
 Mementos: System support for long-running computation on rfid-scale
  devices (technical report).
 Technical Report UM-CS-2010-060, Department of Computer Science,
  University of Massachusetts Amherst, Amherst, MA, October 2010.
[&nbsp;<a href="spqrbib_bib.html#ransford-mementos-tr">bib</a>&nbsp;| 
<a href="http://www.cs.umass.edu/publication/details.php?id=2068">http</a>&nbsp;]
<blockquote><font size="-1">
Keywords: RFID, Operating Systems, Mementos
</font></blockquote>

</dd>


<dt>
[<a name="ransford-asplos2011">RSF11</a>]
</dt>
<dd>
Benjamin Ransford, Jacob Sorber, and Kevin Fu.
 Mementos: System support for long-running computation on RFID-scale
  devices.
 In <em>Proceedings of the 16th International Conference on
  Architectural Support for Programming Languages and Operating Systems</em>,
  ASPLOS '11, Newport Beach, CA, March 2011.
[&nbsp;<a href="spqrbib_bib.html#ransford-asplos2011">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/ransford-mementos-asplos11.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: RFID, Power Management, Operating Systems, UMass Moo, Mementos
</font></blockquote>

</dd>


<dt>
[<a name="molina-BuildSys2010">MMSF<sup>+</sup>10</a>]
</dt>
<dd>
Andres Molina-Markham, Prashant Shenoy, Kevin Fu, Emmanuel Cecchet, and David
  Irwin.
 Private memoirs of a smart meter.
 In <em>2nd ACM Workshop on Embedded Sensing Systems for
  Energy-Efficiency in Buildings (BuildSys 2010)</em>, Zurich, Switzerland,
  November 2010.
[&nbsp;<a href="spqrbib_bib.html#molina-BuildSys2010">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/molina-markham-buildsys10.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Power Management, Privacy, Meters
</font></blockquote>

</dd>


<dt>
[<a name="Defend:2008">DSFI08</a>]
</dt>
<dd>
Benessa Defend, Mastooreh Salajegheh, Kevin Fu, and Sozo Inoue.
 Protecting global medical telemetry infrastructure.
 Technical report, Institute of Information Infrastructure Protection
  (I3P), January 2008.
[&nbsp;<a href="spqrbib_bib.html#Defend:2008">bib</a>&nbsp;| 
<a href="http://www.thei3p.org/docs/publications/whitepaper-protecting_global_medical.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Security, Health
</font></blockquote>

</dd>


<dt>
[<a name="Gummeson:MobiSys2010">GCFG10</a>]
</dt>
<dd>
Jeremy Gummeson, Shane&nbsp;S. Clark, Kevin Fu, and Deepak Ganesan.
 On the limits of effective micro-energy harvesting on mobile CRFID
  sensors.
 In <em>Proceedings of 8th Annual ACM/USENIX International Conference
  on Mobile Systems, Applications, and Services (MobiSys 2010)</em>, pages
  195&ndash;208, June 2010.
[&nbsp;<a href="spqrbib_bib.html#Gummeson:MobiSys2010">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/MobiSys10-SolarCRFID.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: RFID, Power Management, UMass Moo
</font></blockquote>

</dd>


<dt>
[<a name="molina:hiccups">MSF09</a>]
</dt>
<dd>
Andres&nbsp;D. Molina, Mastooreh Salajegheh, and Kevin Fu.
 HICCUPS: Health information collaborative collection using privacy
  and security.
 In <em>Proceedings of the Workshop on Security and Privacy in
  Medical and Home-Care Systems (SPIMACS)</em>, pages 21&ndash;30. ACM Press, November
  2009.
[&nbsp;<a href="spqrbib_bib.html#molina:hiccups">bib</a>&nbsp;| 
<a href="http://dx.doi.org/10.1145/1655084.1655089">DOI</a>&nbsp;| 
<a href="http://dx.doi.org/10.1145/1655084.1655089">http</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Crypto, Health, Security, Privacy
</font></blockquote>

</dd>


<dt>
[<a name="HR09-Ransford">LFK<sup>+</sup>09</a>]
</dt>
<dd>
Sinjin Lee, Kevin Fu, Tadayoshi Kohno, Benjamin Ransford, and William&nbsp;H.
  Maisel.
 Clinically significant magnetic interference of implanted cardiac
  devices by portable headphones.
 <em>Heart Rhythm Journal</em>, 6(10):1432&ndash;1436, October 2009.
[&nbsp;<a href="spqrbib_bib.html#HR09-Ransford">bib</a>&nbsp;| 
<a href="http://download.journals.elsevierhealth.com/pdfs/journals/1547-5271/PIIS1547527109007401.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Health, Journal Paper
</font></blockquote>

</dd>


<dt>
[<a name="Clark:AP-CRFID:HotPower2009">CGFG09</a>]
</dt>
<dd>
Shane&nbsp;S. Clark, Jeremy Gummeson, Kevin Fu, and Deepak Ganesan.
 Towards autonomously-powered CRFIDs.
 In <em>Workshop on Power Aware Computing and Systems (HotPower
  2009)</em>, October 2009.
[&nbsp;<a href="spqrbib_bib.html#Clark:AP-CRFID:HotPower2009">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/clark-autonomous-CRFID-hotpower09.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: RFID, Power Management
</font></blockquote>

</dd>


<dt>
[<a name="fu:imd-cacm">Fu09</a>]
</dt>
<dd>
Kevin Fu.
 Inside risks, reducing the risks of implantable medical devices: A
  prescription to improve security and privacy of pervasive health care.
 <em>Communications of the ACM</em>, 52(6):25&ndash;27, June 2009.
[&nbsp;<a href="spqrbib_bib.html#fu:imd-cacm">bib</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Health, Security, Privacy
</font></blockquote>

</dd>


<dt>
[<a name="salajegheh-usenixsec2009">SCR<sup>+</sup>09</a>]
</dt>
<dd>
Mastooreh Salajegheh, Shane&nbsp;S. Clark, Benjamin Ransford, Kevin Fu, and Ari
  Juels.
 CCCP: secure remote storage for computational RFIDs.
 In <em>Proceedings of the 18th USENIX Security Symposium</em>, pages
  215&ndash;230, Montreal, Canada, August 2009.
[&nbsp;<a href="spqrbib_bib.html#salajegheh-usenixsec2009">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/salajegheh-CCCP-usenix09.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Security, Privacy, RFID, Crypto
</font></blockquote>

</dd>


<dt>
[<a name="salajegheh-DMD09">SMF09</a>]
</dt>
<dd>
Mastooreh Salajegheh, Andres Molina, and Kevin Fu.
 Privacy of home telemedicine: Encryption is not enough.
 <em>Journal of Medical Devices</em>, 3(2), April 2009.
 Design of Medical Devices Conference Abstracts.
[&nbsp;<a href="spqrbib_bib.html#salajegheh-DMD09">bib</a>&nbsp;| 
<a href="http://dx.doi.org/10.1115/1.3134785">DOI</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/salajegheh-DMD09-abstract.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Health, Security
</font></blockquote>

</dd>


<dt>
[<a name="AHA08-Ransford">LRF<sup>+</sup>08</a>]
</dt>
<dd>
Sinjin Lee, Benjamin Ransford, Kevin Fu, Tadayoshi Kohno, and William&nbsp;H.
  Maisel.
 Electromagnetic interference (EMI) of implanted cardiac devices by
  MP3 player headphones.
 <em>Circulation</em>, 118(18 Supplement), November 2008.
 Abstract 662, 2008 American Heart Association Annual Scientific
  Sessions.
[&nbsp;<a href="spqrbib_bib.html#AHA08-Ransford">bib</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Health, Journal Paper
</font></blockquote>

</dd>


<dt>
[<a name="Holcomb:FERNS2009">HBF09</a>]
</dt>
<dd>
Daniel&nbsp;E. Holcomb, Wayne&nbsp;P. Burleson, and Kevin Fu.
 Power-up SRAM state as an identifying fingerprint and source of
  true random numbers.
 <em>IEEE Transactions on Computers</em>, 58(9):1198&ndash;1210, September
  2009.
[&nbsp;<a href="spqrbib_bib.html#Holcomb:FERNS2009">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/holcomb-FERNS-IEEE-Computers.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Security, RFID, Crypto, Journal Paper
</font></blockquote>

</dd>


<dt>
[<a name="hotpower08-ransford">RCSF08</a>]
</dt>
<dd>
Benjamin Ransford, Shane&nbsp;S. Clark, Mastooreh Salajegheh, and Kevin Fu.
 Getting things done on computational RFIDs with energy-aware
  checkpointing and voltage-aware scheduling.
 In <em>USENIX Workshop on Power Aware Computing and Systems
  (HotPower)</em>, December 2008.
[&nbsp;<a href="spqrbib_bib.html#hotpower08-ransford">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/ransford-CRFIDs-hotpower08-30112008.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Power Management, RFID, Mementos
</font></blockquote>

</dd>


<dt>
[<a name="hotsec08-denning">DFK08</a>]
</dt>
<dd>
Tamara Denning, Kevin Fu, and Tadayoshi Kohno.
 Absence makes the heart grow fonder: New directions for implantable
  medical device security.
 In <em>Proceedings of USENIX Workshop on Hot Topics in Security
  (HotSec)</em>, July 2008.
[&nbsp;<a href="spqrbib_bib.html#hotsec08-denning">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/watchdog-hotsec08.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Security, Health
</font></blockquote>

</dd>


<dt>
[<a name="Halperin:ICD">HHBR<sup>+</sup>08</a>]
</dt>
<dd>
Daniel Halperin, Thomas&nbsp;S. Heydt-Benjamin, Benjamin Ransford, Shane&nbsp;S. Clark,
  Benessa Defend, Will Morgan, Kevin Fu, Tadayoshi Kohno, and William&nbsp;H.
  Maisel.
 Pacemakers and implantable cardiac defibrillators: Software radio
  attacks and zero-power defenses.
 In <em>Proceedings of the 29th Annual IEEE Symposium on Security and
  Privacy</em>, pages 129&ndash;142, May 2008.
[&nbsp;<a href="spqrbib_bib.html#Halperin:ICD">bib</a>&nbsp;| 
<a href="http://www.secure-medicine.org/icd-study/icd-study.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Security, Privacy, Health, Award Paper
</font></blockquote>

</dd>


<dt>
[<a name="Halperin:2008fk">HHBF<sup>+</sup>08</a>]
</dt>
<dd>
Daniel Halperin, Thomas&nbsp;S. Heydt-Benjamin, Kevin Fu, Tadayoshi Kohno, and
  William&nbsp;H. Maisel.
 Security and privacy for implantable medical devices.
 <em>IEEE Pervasive Computing, Special Issue on Implantable
  Electronics</em>, 7(1):30&ndash;39, January 2008.
[&nbsp;<a href="spqrbib_bib.html#Halperin:2008fk">bib</a>&nbsp;| 
<a href="http://dx.doi.org/10.1109/MPRV.2008.16">DOI</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/b1kohFINAL2.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Security, Health, Journal Paper
</font></blockquote>

</dd>


<dt>
[<a name="Holcomb:2007uq">HBF07</a>]
</dt>
<dd>
Daniel&nbsp;E. Holcomb, Wayne&nbsp;P. Burleson, and Kevin Fu.
 Initial SRAM state as a fingerprint and source of true random
  numbers for RFID tags.
 In <em>Proceedings of the Conference on RFID Security</em>, July 2007.
[&nbsp;<a href="spqrbib_bib.html#Holcomb:2007uq">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/holcomb-FERNS-RFIDSec07.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: RFID, Crypto, Security
</font></blockquote>

</dd>


<dt>
[<a name="Chae:2007fk">CYSF07</a>]
</dt>
<dd>
Hee-Jin Chae, Daniel&nbsp;J. Yeager, Joshua&nbsp;R. Smith, and Kevin Fu.
 Maximalist cryptography and computation on the WISP UHF RFID
  tag.
 In <em>Proceedings of the Conference on RFID Security</em>, July 2007.
[&nbsp;<a href="spqrbib_bib.html#Chae:2007fk">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/chae-RFIDSec07.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: RFID, Crypto, Security
</font></blockquote>

</dd>


<dt>
[<a name="Defend:2007uq">DFJ07</a>]
</dt>
<dd>
Benessa Defend, Kevin Fu, and Ari Juels.
 Cryptanalysis of two lightweight RFID authentication schemes.
 In <em>Fourth IEEE International Workshop on Pervasive Computing and
  Communication Security (PerSec) Workshop</em>, March 2007.
[&nbsp;<a href="spqrbib_bib.html#Defend:2007uq">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/defend-persec07.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: RFID, Crypto, Security
</font></blockquote>

</dd>


<dt>
[<a name="Heydt-Benjamin:2007fk">HBBF<sup>+</sup>07</a>]
</dt>
<dd>
Thomas&nbsp;S. Heydt-Benjamin, Dan&nbsp;V. Bailey, Kevin Fu, Ari Juels, and Tom OHare.
 Vulnerabilities in first-generation RFID-enabled credit cards.
 In <em>Proceedings of Eleventh International Conference on Financial
  Cryptography and Data Security, Lecture Notes in Computer Science, Vol.
  4886</em>, pages 2&ndash;14, Lowlands, Scarborough, Trinidad/Tobago, February 2007.
[&nbsp;<a href="spqrbib_bib.html#Heydt-Benjamin:2007fk">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/RFID-CC-LNCS.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Security, RFID
</font></blockquote>

</dd>


<dt>
[<a name="fu:cookies-cacm">SF01</a>]
</dt>
<dd>
Emil Sit and Kevin Fu.
 Inside risks, web cookies: Not just a privacy risk.
 <em>Communications of the ACM</em>, 44(9):120, September 2001.
[&nbsp;<a href="spqrbib_bib.html#fu:cookies-cacm">bib</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Security, Crypto, Cookies
</font></blockquote>

</dd>


<dt>
[<a name="Ateniese:2005fk">AFGH05</a>]
</dt>
<dd>
Giuseppe Ateniese, Kevin Fu, Matthew Green, and Susan Hohenberger.
 Improved proxy re-encryption schemes with applications to secure
  distributed storage.
 In <em>Proceedings of the Symposium on Network and Distributed
  System Security (NDSS)</em>. ISOC, February 2005.
[&nbsp;<a href="spqrbib_bib.html#Ateniese:2005fk">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/ateniese-proxy-reenc-ndss05.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Security
</font></blockquote>

</dd>


<dt>
[<a name="Rubin:1997fj">RBF97</a>]
</dt>
<dd>
Aviel&nbsp;D. Rubin, Dan Boneh, and Kevin Fu.
 Revocation of unread email in an untrusted network.
 In <em>Proceedings of Information Security and Privacy, Second
  Australasian Conference (ACISP), Springer-Verlag, Lecture Notes in Computer
  Science, Vol. 1270</em>, pages 62&ndash;75, Sydney, Australia, July 1997.
[&nbsp;<a href="spqrbib_bib.html#Rubin:1997fj">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/email.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Security, Crypto
</font></blockquote>

</dd>


<dt>
[<a name="Graveman:1999qy">GF99</a>]
</dt>
<dd>
Richard Graveman and Kevin Fu.
 Approximate message authentication codes.
 Technical report, Bellcore, February 1999.
 Army Research Labs ATIRP.
[&nbsp;<a href="spqrbib_bib.html#Graveman:1999qy">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/graveman-amac.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Security, Crypto, Tech Report
</font></blockquote>

</dd>


<dt>
[<a name="fu:using-sfs">FKM02b</a>]
</dt>
<dd>
Kevin Fu, Michael Kaminsky, and David Mazieres.
 Using SFS for a secure network file system.
 <em>;login: The Magazine of Usenix &amp; Sage</em>, 27(6):6&ndash;16, December
  2002.
[&nbsp;<a href="spqrbib_bib.html#fu:using-sfs">bib</a>&nbsp;| 
<a href="http://www.usenix.org/publications/login/2002-12/pdfs/Fu.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Security, Operating Systems
</font></blockquote>

</dd>


<dt>
[<a name="hotsec06-bellissimo">BBF06</a>]
</dt>
<dd>
Anthony Bellissimo, John Burgess, and Kevin Fu.
 Secure software updates: disappointments and new challenges.
 In <em>Proceedings of USENIX Hot Topics in Security (HotSec)</em>, July
  2006.
[&nbsp;<a href="spqrbib_bib.html#hotsec06-bellissimo">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/secureupdates-hotsec06.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Security
</font></blockquote>

</dd>


<dt>
[<a name="pet06-heydt">HBCDF06</a>]
</dt>
<dd>
Thomas&nbsp;S. Heydt-Benjamin, Hee-Jin Chae, Benessa Defend, and Kevin Fu.
 Privacy for public transportation.
 In <em>Proceedings of Privacy Enhancing Technologies workshop (PET
  2006), Lecture Notes in Computer Science, Vol. 4258</em>, pages 1&ndash;19, June 2006.
[&nbsp;<a href="spqrbib_bib.html#pet06-heydt">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/heydt-benjamin-pet06.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Security, Anonymity, RFID
</font></blockquote>

</dd>


<dt>
[<a name="fu:keyregression">FKK06</a>]
</dt>
<dd>
Kevin Fu, Seny Kamara, and Tadayoshi Kohno.
 Key regression: Enabling efficient key distribution for secure
  distributed storage.
 In <em>Proceedings of the Symposium on Network and Distributed
  Systems Security</em>, February 2006.
[&nbsp;<a href="spqrbib_bib.html#fu:keyregression">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/fu-key-regression-ndss06.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Security, Crypto, Operating Systems
</font></blockquote>

</dd>


<dt>
[<a name="ateniese:proxy-reenc">AFGH06</a>]
</dt>
<dd>
Giuseppe Ateniese, Kevin Fu, Matthew Green, and Susan Hohenberger.
 Improved proxy re-encryption schemes with applications to secure
  distributed storage.
 <em>ACM Transactions on Information and System Security (TISSEC)</em>,
  9(1), February 2006.
 An early version appeared in Proceedings of the Network and
  Distributed Systems Security Symposium (2005).
[&nbsp;<a href="spqrbib_bib.html#ateniese:proxy-reenc">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/ateniese-proxy-reenc-tissec.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Security, Crypto, Operating Systems, Journal Paper
</font></blockquote>

</dd>


<dt>
[<a name="fu:masters">Fu99</a>]
</dt>
<dd>
Kevin Fu.
 Group sharing and random access in cryptographic storage file
  systems.
 Master's thesis, Massachusetts Institute of Technology, May 1999.
[&nbsp;<a href="spqrbib_bib.html#fu:masters">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/fu-masters.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Security, Crypto, Operating Systems, Thesis
</font></blockquote>

</dd>


<dt>
[<a name="webauth:tr">FSSF01a</a>]
</dt>
<dd>
Kevin Fu, Emil Sit, Kendra Smith, and Nick Feamster.
 Dos and don'ts of client authentication on the web.
 Technical Report MIT-LCS-TR-818, MIT Lab for Computer Science, May
  2001.
[&nbsp;<a href="spqrbib_bib.html#webauth:tr">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/webauth-tr.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Security, Crypto, Tech Report, Cookies
</font></blockquote>

</dd>


<dt>
[<a name="sfsro:tocs2002">FKM02a</a>]
</dt>
<dd>
Kevin Fu, M.&nbsp;Frans Kaashoek, and David Mazieres.
 Fast and secure distributed read-only file system.
 <em>ACM Transactions on Computer Systems</em>, 20(1):1&ndash;24, February
  2002.
[&nbsp;<a href="spqrbib_bib.html#sfsro:tocs2002">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/sfsro-tocs.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Security, Operating Systems, Journal Paper
</font></blockquote>

</dd>


<dt>
[<a name="sfsro:osdi2000">FKM00</a>]
</dt>
<dd>
Kevin Fu, M.&nbsp;Frans Kaashoek, and David Mazieres.
 Fast and secure distributed read-only file system.
 In <em>Proceedings of the 4th USENIX Symposium on Operating Systems
  Design and Implementation (OSDI 2000)</em>, pages 181&ndash;196, San Diego,
  California, October 2000.
[&nbsp;<a href="spqrbib_bib.html#sfsro:osdi2000">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/sfsro-osdi2000.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Security, Operating Systems
</font></blockquote>

</dd>


<dt>
[<a name="fu-phd">Fu05</a>]
</dt>
<dd>
Kevin Fu.
 <em>Integrity and access control in untrusted content distribution
  networks</em>.
 PhD thesis, MIT, September 2005.
[&nbsp;<a href="spqrbib_bib.html#fu-phd">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/fu-phd-thesis.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Security, Crypto, Operating Systems, Thesis
</font></blockquote>

</dd>


<dt>
[<a name="rex:usenix04">KPG<sup>+</sup>04</a>]
</dt>
<dd>
Michael Kaminsky, Eric Peterson, Daniel&nbsp;B. Giffin, Kevin Fu, David Mazieres,
  and M.&nbsp;Frans Kaashoek.
 REX: Secure, extensible remote execution.
 In <em>Proceedings of the 2004 USENIX Annual Technical Conference
  (USENIX '04)</em>, pages 199&ndash;212, Boston, Massachusetts, June 2004.
[&nbsp;<a href="spqrbib_bib.html#rex:usenix04">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/rex-usenix04.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Security, Operating Systems
</font></blockquote>

</dd>


<dt>
[<a name="webauth:sec10">FSSF01b</a>]
</dt>
<dd>
Kevin Fu, Emil Sit, Kendra Smith, and Nick Feamster.
 Dos and don'ts of client authentication on the web.
 In <em>Proceedings of the 10th USENIX Security Symposium</em>,
  Washington, D.C., August 2001.
 An extended version is available as MIT-LCS-TR-818 (Best Student
  Paper Award).
[&nbsp;<a href="spqrbib_bib.html#webauth:sec10">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/webauth-sec01.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Security, Crypto, Award Paper, Cookies
</font></blockquote>

</dd>


<dt>
[<a name="plutus:fast02">KRS<sup>+</sup>03</a>]
</dt>
<dd>
Mahesh Kallahalla, Erik Riedel, Ram Swaminathan, Qian Wang, and Kevin Fu.
 Plutus: Scalable secure file sharing on untrusted storage.
 In <em>Proc. USENIX Conference on File and Storage Technologies</em>,
  pages 29&ndash;42, San Francisco, CA, December 2003.
[&nbsp;<a href="spqrbib_bib.html#plutus:fast02">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/FAST2003-plutus.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Security, Operating Systems
</font></blockquote>

</dd>


<dt>
[<a name="zhang-moo-tr">ZGRF11</a>]
</dt>
<dd>
Hong Zhang, Jeremy Gummeson, Benjamin Ransford, and Kevin Fu.
 Moo: A batteryless computational RFID and sensing platform.
 Technical Report UM-CS-2011-020, Department of Computer Science,
  University of Massachusetts Amherst, Amherst, MA, June 2011.
[&nbsp;<a href="spqrbib_bib.html#zhang-moo-tr">bib</a>&nbsp;| 
<a href="http://www.cs.umass.edu/publication/details.php?id=2114">http</a>&nbsp;]
<blockquote><font size="-1">
Keywords: RFID, Hardware, UMass Moo
</font></blockquote>

</dd>


<dt>
[<a name="ransford-bootie">Ran10</a>]
</dt>
<dd>
Benjamin Ransford.
 A rudimentary bootloader for computational RFIDs.
 Technical Report UM-CS-2010-061, Department of Computer Science,
  University of Massachusetts Amherst, Amherst, MA, April 2010.
[&nbsp;<a href="spqrbib_bib.html#ransford-bootie">bib</a>&nbsp;| 
<a href="http://www.cs.umass.edu/publication/details.php?id=2069">http</a>&nbsp;]
<blockquote><font size="-1">
Keywords: RFID, Operating Systems
</font></blockquote>

</dd>


<dt>
[<a name="burleson-imd-dac">BCRF12</a>]
</dt>
<dd>
Wayne&nbsp;P. Burleson, Shane&nbsp;S. Clark, Benjamin Ransford, and Kevin Fu.
 Design challenges for secure implantable medical devices.
 In <em>Proceedings of the 49th Design Automation Conference</em>, DAC
  '12, June 2012.
 Invited paper.
[&nbsp;<a href="spqrbib_bib.html#burleson-imd-dac">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/49SS2-3_burleson.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Security, Health
</font></blockquote>

</dd>


<dt>
[<a name="rahmati-usenixsec2012">RSH<sup>+</sup>12b</a>]
</dt>
<dd>
Amir Rahmati, Mastooreh Salajegheh, Dan Holcomb, Jacob Sorber, Wayne&nbsp;P.
  Burleson, and Kevin Fu.
 TARDIS: Time and remanence decay in SRAM to implement secure
  protocols on embedded devices without clocks.
 In <em>Proceedings of the 21st USENIX Security Symposium</em>, Security
  '12, Bellevue, WA, August 2012.
[&nbsp;<a href="spqrbib_bib.html#rahmati-usenixsec2012">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/rahmati-usenix12.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Security, Privacy, RFID
</font></blockquote>

</dd>


<dt>
[<a name="rahmati-oakland2012">RSH<sup>+</sup>12a</a>]
</dt>
<dd>
Amir Rahmati, Mastooreh Salajegheh, Dan Holcomb, Jacob Sorber, Wayne&nbsp;P.
  Burleson, and Kevin Fu.
 Tardis: Secure time keeping for embedded devices without clocks.
 In <em>Poster and Short Talk session of 33rd Annual IEEE Symposium
  on Security and Privacy</em>, San Francisco, CA, May 2012.
[&nbsp;<a href="spqrbib_bib.html#rahmati-oakland2012">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/tardis/TARDIS_Abstract_Oakland12.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Security, Privacy, RFID
</font></blockquote>

</dd>


<dt>
[<a name="holcomb-rfidsec2012">HRS<sup>+</sup>12</a>]
</dt>
<dd>
Dan Holcomb, Amir Rahmati, Mastooreh Salajegheh, Wayne&nbsp;P. Burleson, and Kevin
  Fu.
 Drv-fingerprinting: Using data retention voltage of sram cells for
  chip identification.
 In <em>The 8th Workshop On RFID Security And Privacy</em>, RFIDSec '12,
  Nijmegen, The Netherlands, July 2012.
[&nbsp;<a href="spqrbib_bib.html#holcomb-rfidsec2012">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/holcomb-rfidsec12.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Security, RFID, PUF
</font></blockquote>

</dd>


<dt>
[<a name="kramer-postmarket-plos-one">KBR<sup>+</sup>12</a>]
</dt>
<dd>
Daniel&nbsp;B. Kramer, Matthew Baker, Benjamin Ransford, Andres Molina-Markham,
  Quinn Stewart, Kevin Fu, and Matthew&nbsp;R. Reynolds.
 Security and privacy qualities of medical devices: An analysis of
  FDA postmarket surveillance.
 <em>PLoS ONE</em>, 7(7):e40200, July 2012.
[&nbsp;<a href="spqrbib_bib.html#kramer-postmarket-plos-one">bib</a>&nbsp;| 
<a href="http://www.plosone.org/article/fetchObjectAttachment.action?uri=info%3Adoi%2F10.1371%2Fjournal.pone.0040200&representation=PDF">http</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Security, Health
</font></blockquote>

</dd>


<dt>
[<a name="clark-hotsec2012">CRF12</a>]
</dt>
<dd>
Shane&nbsp;S. Clark, Benjamin Ransford, and Kevin Fu.
 Potentia est scientia: Security and privacy implications of
  energy-proportional computing.
 In <em>Proceedings of the 7th USENIX Workshop on Hot Topics in
  Security</em>, HotSec '12, Bellevue, WA, August 2012.
[&nbsp;<a href="spqrbib_bib.html#clark-hotsec2012">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/clark-potentia-hotsec12.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Security, Privacy, Power, Medical Device, Malware, Power Analysis
</font></blockquote>

</dd>


<dt>
[<a name="walls-hotsec2012">WCL12</a>]
</dt>
<dd>
Robert&nbsp;J. Walls, Shane&nbsp;S. Clark, and Brian&nbsp;Neil Levine.
 Functional privacy or why cookies are better with milk.
 In <em>Proceedings of the 7th USENIX Workshop on Hot Topics in
  Security</em>, HotSec '12, Bellevue, WA, August 2012.
[&nbsp;<a href="spqrbib_bib.html#walls-hotsec2012">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/walls-hotsec12.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Cookies, Privacy
</font></blockquote>

</dd>


<dt>
[<a name="molina-crfidbook2012">MMCRF12</a>]
</dt>
<dd>
Andres Molina-Markham, Shane&nbsp;S. Clark, Benjamin Ransford, and Kevin Fu.
 <em>Wirelessly Powered Sensor Networks and Computational RFID</em>,
  chapter BAT: Backscatter Anything-to-Tag Communication.
 Springer, 2012.
[&nbsp;<a href="spqrbib_bib.html#molina-crfidbook2012">bib</a>&nbsp;| 
<a href="http://www.springer.com/engineering/signals/book/978-1-4419-6165-5">http</a>&nbsp;]
<blockquote><font size="-1">
Keywords: RFID, Networking
</font></blockquote>

</dd>


<dt>
[<a name="molina-markham-phd">MM12</a>]
</dt>
<dd>
Andres Molina-Markham.
 <em>Privacy-aware Collaboration Among Untrusted Resource Constrained
  Devices</em>.
 PhD thesis, University of Massachusetts Amherst, September 2012.
[&nbsp;<a href="spqrbib_bib.html#molina-markham-phd">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/molina-markham-phd-thesis.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Privacy, Security, Crypto, Distributed Systems, Thesis
</font></blockquote>

</dd>


<dt>
[<a name="ransford-phd">Ran13</a>]
</dt>
<dd>
Benjamin Ransford.
 <em>Transiently Powered Computers</em>.
 PhD thesis, University of Massachusetts Amherst, January 2013.
[&nbsp;<a href="spqrbib_bib.html#ransford-phd">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/ransford-thesis.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Thesis, Mementos, Medical Device, RFID, Power Management, Operating Systems, UMass Moo
</font></blockquote>

</dd>


<dt>
[<a name="clark-phd">Cla13</a>]
</dt>
<dd>
Shane&nbsp;S. Clark.
 <em>The Security and Privacy Implications of Energy-Proportional
  Computing</em>.
 PhD thesis, University of Massachusetts Amherst, September 2013.
[&nbsp;<a href="spqrbib_bib.html#clark-phd">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/ssclark-thesis.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Thesis, Security, Privacy, Power Analysis, Health, Medical
		Device
</font></blockquote>

</dd>


<dt>
[<a name="clark-currentevents-esorics">CMR<sup>+</sup>13</a>]
</dt>
<dd>
Shane&nbsp;S. Clark, Hossen Mustafa, Benjamin Ransford, Jacob Sorber, Kevin Fu, and
  Wenyuan Xu.
 Current Events: Identifying webpages by tapping the electrical
  outlet.
 In <em>Proceedings of the 18th European Symposium on Research in
  Computer Security (ESORICS)</em>, September 2013.
[&nbsp;<a href="spqrbib_bib.html#clark-currentevents-esorics">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/clark-esorics13.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Side Channels, Privacy, Power Analysis
</font></blockquote>

</dd>


<dt>
[<a name="clark-healthtech13">CRR<sup>+</sup>13</a>]
</dt>
<dd>
Shane&nbsp;S. Clark, Benjamin Ransford, Amir Rahmati, Shane Guineau, Jacob Sorber,
  Wenyuan Xu, and Kevin Fu.
 WattsUpDoc: Power side channels to nonintrusively discover
  untargeted malware on embedded medical devices.
 In <em>USENIX Workshop on Health Information Technologies</em>, August
  2013.
[&nbsp;<a href="spqrbib_bib.html#clark-healthtech13">bib</a>&nbsp;| 
<a href="https://spqr.eecs.umich.edu/papers/clark-healthtech13.pdf">.pdf</a>&nbsp;]
<blockquote><font size="-1">
Keywords: Security, Health, Power Analysis
</font></blockquote>

</dd>
</dl><hr><p><em>This file was generated by
<a href="http://www.lri.fr/~filliatr/bibtex2html/">bibtex2html</a> 1.96.</em></p>

</div> <!-- /publications -->

</div> <!-- /meat -->

</div> <!-- /main -->

</body>
</html>
