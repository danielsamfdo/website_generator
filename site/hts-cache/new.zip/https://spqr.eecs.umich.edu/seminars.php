<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="keywords" content="">
    <!-- facebook -->
    <meta property="og:url" content="https://spqr.eecs.umich.edu/" />
	<meta property="og:site_name" content="SPQR - Security and Privacy Research Group" />
	<meta property="og:type" content="website" />
	<meta property="og:title" content="SPQR - Security and Privacy Research Group" />
	<meta property="og:image" content="http://localhost/spqr/images/SPQR-logo.jpg" />
	<meta property="og:description" content="" />

    <link rel="shortcut icon" href="images/spqr-favicon.png">

    <title>SPQR &mdash; Michigan EECS</title>

    <!-- Bootstrap core CSS -->
    <link href="dist/css/bootstrap.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy this line! -->
    <!--[if lt IE 9]><script src="../../docs-assets/js/ie8-responsive-file-warning.js"></script><![endif]-->

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->

    <!-- Custom styles for this template -->
    <link href="styles/bootstrap-spqr.css" rel="stylesheet">

  </head>  <body>
	    <div class="navbar-wrapper">
      <div class="container">

        <div class="navbar navbar-inverse navbar-static-top" role="navigation">
          <div class="container">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              <a class="navbar-brand" href="index.php">
              <div class="nav-header-logo">
                <script src="spqr.js"></script>
		<span onMouseOver="SPQRlink(this)">
              	<img src="images/SPQR-logo.jpg" class="nav-header-logo-img">
		</span>
              </div>
              <div class="nav-header-headline">Security and Privacy Research Group</div>
              <div class="nav-header-text">Computer Science & Engineering | University of Michigan</div> 
              </a>
            </div>
            <div class="navbar-collapse collapse">
              <ul class="nav navbar-nav">
               <li ><a href="index.php">HOME</a></li>
                <li ><a href="people.php">PEOPLE</a></li>
                <li ><a href="publications.php">PUBLICATIONS</a></li>
                <li ><a href="projects.php">PROJECTS</a></li>
                <li ><a href="news.php">NEWS & EVENTS</a></li>
                <li  class="active" ><a href="seminars.php">SEMINARS</a></li>
                <li ><a href="jobs.php">JOBS</a></li>
                <li ><a href="https://twitter.com/spqrfridge">SMART FRIDGE</a></li>
              </ul>
            </div>
          </div>
        </div>

      </div>
    </div>    <div class="container marketing">
    <div class="col-md-12 content-first-col news">
	<h2>Seminars</h2>
           <br />
           <p>Seminar announcements appear in the <a href="http://cse.umich.edu/">departmental calendar</a>.  Our older seminars appear below.</p>
           <br />
	  <div class="row">
  		<div class="col-md-1 newsNext"><h2>2013</h2></div>
    	<div class="col-md-1"><h2>Oct</h2></div>
  		<div class="col-md-10"></div>
  	  </div>
  	  <div class="row">
  		<div class="col-md-1">&nbsp;</div>
  		<div class="col-md-1">&nbsp;</div>
  		<div class="col-md-10 newsItem"><a target="_blank" href="events/2013-dan-holcomb/">Dan Holcomb</a>,  SRAM fingerprinting using power-up state minimum data retention voltages,  October 22, 2013</div>
  	  </div>
	  <div class="row">
  		<div class="col-md-1">&nbsp;</div>
    	<div class="col-md-1"><h2>Jun</h2></div>
  		<div class="col-md-10"></div>
  	  </div>  	  
  	  <div class="row">
  		<div class="col-md-1">&nbsp;</div>
  		<div class="col-md-1">&nbsp;</div>
  		<div class="col-md-10 newsItem">Colleen Swanson, Combinatorial Solutions for the Generalized Russian Cards Problem, June 14, 2013</div>
  	  </div>      
	  <div class="row">
  		<div class="col-md-1 newsNext"><h2>2011</h2></div>
    	<div class="col-md-1"><h2>Jun</h2></div>
  		<div class="col-md-10"></div>
  	  </div>
  	  <div class="row">
  		<div class="col-md-1">&nbsp;</div>
  		<div class="col-md-1">&nbsp;</div>
  		<div class="col-md-10 newsItem"><a target="_blank" href="events/2011-regazzoni/">Francesco Regazzoni</a>,  Towards Automatic Application of Power Analysis Countermeasures,  June 29, 2011</div>
  	  </div>
	  <div class="row">
  		<div class="col-md-1">&nbsp;</div>
    	<div class="col-md-1"><h2>Apr</h2></div>
  		<div class="col-md-10"></div>
  	  </div>
  	  <div class="row">
  		<div class="col-md-1">&nbsp;</div>
  		<div class="col-md-1">&nbsp;</div>
  		<div class="col-md-10 newsItem"><a target="_blank" href="events/mcgraw/">Gary McGraw</a>, Attack Trends 2011: Why Software Security?, April 28, 2011</div>
  	  </div>    	  
	  <div class="row">
  		<div class="col-md-1">&nbsp;</div>
    	<div class="col-md-1"><h2>Mar</h2></div>
  		<div class="col-md-10"></div>
  	  </div>
  	  <div class="row">
  		<div class="col-md-1">&nbsp;</div>
  		<div class="col-md-1">&nbsp;</div>
  		<div class="col-md-10 newsItem"><a target="_blank" href="events/2011-king-sam/">Samuel T. King</a>, Trust and Protection in the Illinois Browser Operating System, March 24, 2011</div>
  	  </div>   	  
 	
	  <div class="row">
  		<div class="col-md-1 newsNext"><h2>2010</h2></div>
    	<div class="col-md-1"><h2>Oct</h2></div>
  		<div class="col-md-10"></div>
  	  </div> 	  
  	  <div class="row">
  		<div class="col-md-2"></div>
  		<div class="col-md-10 newsItem"><a target="_blank" href="events/2010-xu-wenyuan/">Wenyuan Xu</a>, Analyzing the Security and Privacy Vulnerability of Emerging Wireless Networks via Software Defined Radio, October 25, 2010</div>
  	  </div>   	  	    	  
	  <div class="row">
  		<div class="col-md-1 newsNext"><h2>2009</h2></div>
    	<div class="col-md-1"><h2>Sep</h2></div>
  		<div class="col-md-10"></div>
  	  </div>	  
  	  <div class="row">
  		<div class="col-md-2"></div>
  		<div class="col-md-10 newsItem"><a target="_blank" href="events/2009-jiang-andrew/">Anxiao (Andrew) Jiang</a>, Coding for Flash Memories, September 18, 2009</div>
  	  </div> 
	  <div class="row">
  		<div class="col-md-1">&nbsp;</div>
    	<div class="col-md-1"><h2>Apr</h2></div>
  		<div class="col-md-10"></div>
  	  </div>  	    
  	  <div class="row">
  		<div class="col-md-2"></div>
  		<div class="col-md-10 newsItem"><a target="_blank" href="events/2009-clarke-richard/">Richard Clarke</a>, The missing pieces of the three 21st century wars: Iraq, Afghanistan and Cyberspace, April 2, 2009</div>
  	  </div>    	   	  
    </div>
    <hr class="featurette-divider">
    <!--<div class="watermark-title">SEMINARS</div>   --> 
      <!-- FOOTER -->
      <footer>
        <p class="pull-right"><a href="#">Back to top</a></p>
        <p>&copy; 2015 Security and Privacy Research Group - University of Michigan</p>
      </footer>

    </div><!-- /.container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
    <script src="dist/js/bootstrap.min.js"></script>
    <script src="docs-assets/js/holder.js"></script>
  </body>
</html>
